from linepy import *
from akad.ttypes import *
from multiprocessing import Pool, Process
from threading import Thread
import time, asyncio, json, threading, codecs, sys, os, re, urllib, requests, wikipedia, html5lib, timeit, pafy, youtube_dl
from bs4 import BeautifulSoup
from Naked.toolshed.shell import execute_js 
Creator = ["u317784607b57c5d953852660d99ca3df"]
RAKey = "!"
mulai = time.time()

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
    
class LineBot(object):
    
    def __init__(self, resp, authQR=None):
        self.resp = resp
        self.resp = self.resp+' '
        self.authQR = authQR
        self.login(authQR)
        self.fetch()
        
    def login(self, auth):
        if auth == None:
            self.client = LINE()
        else:
            self.client = LINE(auth)
        #self.client_ch = LineChannel(self.client, channelId="1341209850")
        self.client.log("Auth Token : " + str(self.client.authToken))
        #self.client.log("Channel Token : " + str(self.client_ch.channelAccessToken))
        self.mid = self.client.getProfile().mid
        self.RAset = {
        	"RAGfoto": {},
        	"RAfoto": {},
        	"RAgreet": {},
        	"RAprotcancel": {},
        	"RAprotinvite": {},
        	"RAprotkick": {},
        	"RAprotqr": {},
        	"RAreadMember": {},
        	"RAreadPoint": {},
        	"modewar": False
        	}
        self.wait = {
        	"ACreator": False,
        	"DCreator": False,
        	"GLOwner": False,
        	"GLcust": {},
        	"Owner": {
        		"u317784607b57c5d953852660d99ca3df":True,
        		},
        	"RAAdmin": {},
        	"RABots": {},
        	"RASDadmin": False,
        	"RASDbot": False,
        	"RASDstaff": False,
        	"RASbot": False,
        	"RASstaff": False,
        	"RAStaff": {},
        	"RAautojoin": True,
        	"RAautoread": False,
        	"RAautoscan": False,
        	"RAblacklist": {},
        	"RAdblacklist": False,
        	"RAlimit": 1,
        	"RAmessage": "thanks......",
        	"RAmessage1": "Minat? Chat http://line.me/ti/p/~ri-her",
        	"RAwblacklist": False,
        	"limitcancel": False,
        	"limitinvite": False,
        	"limitkick": False
        	}
        
    def fetch(self):
        while True:
            try:
                self.operations = self.client.poll.fetchOperations(self.client.revision, 10)
                for op in self.operations:
                    if (op.type != OpType.END_OF_OPERATION):
                        self.client.revision = max(self.client.revision, op.revision)
                        self.bot(op)
            except Exception:
                pass
					
    def bot(self, op):
        cl = self.client
        wait = self.wait
        try:
            if op.type == 0 or op.type == 50:
                return

            if op.type == 13:
                if self.mid in op.param3:
                    cl.acceptGroupInvitation(op.param1)
            if op.type == 13:
                for op.param2 in self.wait["RAblacklist"]:
                	cl.cancelGroupInvitation(op.param1,[op.param2])
            if op.type == 13:
                if op.param3 in self.wait["RAblacklist"]:
                	self.wait["RAblacklist"][op.param2] = True
                	cl.kickoutFromGroup(op.param1,[op.param2])

            if op.type == 19:
                if op.param3 in self.wait["RABots"]:
                    pasukan = self.wait["RABots"]
                    cl.inviteIntoGroup(op.param1,pasukan)
                    self.wait["RAblacklist"][op.param2] = True
            if op.type == 19:
             if op.param3 in self.mid:
              if op.param2 not in self.wait["Owner"] and op.param2 not in self.wait["RABots"]:
              	self.wait["RAblacklist"][op.param2] = True

            if op.type == 32:
                if op.param3 in self.wait["RABots"]:
                	self.wait["RAblacklist"][op.param2] = True
                	pasukan = self.wait["RABots"]
                	cl.inviteIntoGroup(op.param1,pasukan)

            if op.type == 17:
                if op.param2 in self.wait["RAblacklist"]:
                    self.RAset["modewar"] = True
            if op.type == 11:
                if self.RAset["modewar"] == True:
                	if op.param2 not in self.wait["Owner"] and op.param2 not in self.wait["RABots"]:
                	    G = cl.getGroup(op.param1)
                	    G.name = str('󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳')
                	    cl.updateGroup(G)

            if op.type == 19 or op.type == 17 or op.type == 32 or op.type == 11:
                for op.param2 in self.wait["RAblacklist"]:
                    cl.kickoutFromGroup(op.param1,[op.param2])


            if op.type == 26:
                msg = op.message
                if msg.contentType == 13:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RAwblacklist"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RAblacklist"]:
                                cl.sendMessage(msg.to,"Akun sudah terblacklist")
                            else:
                                self.wait["RAblacklist"][msg.contentMetadata["mid"]] = True
                                cl.sendMessage(msg.to,"Akun terblacklist")
                        elif self.wait["RAdblacklist"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RAblacklist"]:
                                del self.wait["RAblacklist"][msg.contentMetadata["mid"]]
                                cl.sendMessage(msg.to,"Akun dihapus dari blacklist")
                            else:
                                cl.sendMessage(msg.to,"Akun tidak ada di blacklist")
                        elif self.wait["RAautoscan"] == True:
                            msg.contentType = 0
                            cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                            
                    if msg._from in Creator or msg._from in self.wait["Owner"]:         
                        if self.wait["DCreator"] == True:
                            if msg.contentMetadata["mid"] in self.wait["Owner"]:
                                cl.sendMessage(msg.to,"Akun sudah menjadi owner")
                            else:
                                self.wait["Owner"][msg.contentMetadata["mid"]] = True
                                cl.sendMessage(msg.to,"Terdaftar menjadi Owner")
                        elif self.wait["ACreator"] == True:
                            if msg.contentMetadata["mid"] in self.wait["Owner"]:
                                del self.wait["Owner"][msg.contentMetadata["mid"]]
                                cl.sendMessage(msg.to,"Akun dihapus dari Ownerlist")
                            else:
                                cl.sendMessage(msg.to,"Akun tidak ada di Ownerlist")
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:         
                        if self.wait["GLOwner"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RAAdmin"]:
                                cl.sendMessage(msg.to,"Akun sudah menjadi admin")
                            else:
                                self.wait["RAAdmin"][msg.contentMetadata["mid"]] = True
                                cl.sendMessage(msg.to,"Terdaftar menjadi admin")
                        elif self.wait["RASDadmin"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RAAdmin"]:
                                del self.wait["RAAdmin"][msg.contentMetadata["mid"]]
                                cl.sendMessage(msg.to,"Akun dihapus dari adminlist")
                            else:
                                cl.sendMessage(msg.to,"Akun tidak ada di adminlist")
                        elif self.wait["RASstaff"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RAStaff"]:
                                cl.sendMessage(msg.to,"Akun sudah menjadi staff")
                            else:
                                self.wait["RAStaff"][msg.contentMetadata["mid"]] = True
                                cl.sendMessage(msg.to,"Terdaftar menjadi staff")
                        elif self.wait["RASDstaff"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RAStaff"]:
                                del self.wait["RAStaff"][msg.contentMetadata["mid"]]
                                cl.sendMessage(msg.to,"Akun dihapus dari stafflist")
                            else:
                                cl.sendMessage(msg.to,"Akun tidak ada di stafflist")
                                
                    if msg._from in self.wait["Owner"]:
                        if self.wait["RASbot"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RABots"]:
                                cl.sendMessage(msg.to,"Bot sudah masuk list")
                            else:
                                self.wait["RABots"][msg.contentMetadata["mid"]] = True
                                cl.sendMessage(msg.to,"Bot masuk dalam list")
                        elif self.wait["RASDbot"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RABots"]:
                                del self.wait["RABots"][msg.contentMetadata["mid"]]
                                cl.sendMessage(msg.to,"Bot keluar dari list")
                            else:
                                cl.sendMessage(msg.to,"Bot tidak ada di list")
                    
                elif msg.contentType == 1:
                    if msg._from in self.wait["Owner"]:
                        if self.mid in self.RAset["RAfoto"]:
                            path = cl.downloadObjectMsg(msg.id)
                            del self.RAset["RAfoto"][self.mid]
                            cl.updateProfilePicture(path)
                            cl.sendMessage(msg.to,"Foto berhasil dirubah")
                        elif msg.to in self.RAset["RAfoto"]:
                            path = cl.downloadObjectMsg(msg.id)
                            cl.updateProfilePicture(path)
                            del self.RAset["RAfoto"][msg.to]
                            cl.sendMessage(msg.to,"Foto berhasil diperbaharui")
                        if msg.toType == 2:
                            if msg.to in self.RAset["RAGfoto"]:
                                path = cl.downloadObjectMsg(msg.id)
                                del self.RAset["RAGfoto"][msg.to]
                                cl.updateGroupPicture(msg.to, path)
                                cl.sendMessage(msg.to,"Foto grup diperbaharui")
                elif None == msg.text:
                    return
                
#------------------------------- Start Menu ----------------------------------#
            

                elif msg.text == self.resp + 'set':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        md = "☣️Status setting\n ≠≠≠≠≠≠≠≠≠≠≠≠≠≠\n"
                        if self.wait["GLOwner"]== True: md+="✅ Add Admin\n"
                        else: md+="❌ Add Admin\n"
                        if self.wait["RASDadmin"]== True: md+="✅ Dell Admin\n"
                        else: md+="❌ Dell Admin\n"
                        if self.wait["RASstaff"]== True: md+="✅ Add Staff\n"
                        else: md+="❌ Add Staff\n"
                        if self.wait["RASDstaff"]== True: md+="✅ Dell Staff\n"
                        else: md+="❌ Dell Staff\n"
                        if self.wait["RAwblacklist"]== True: md+="✅ Blacklist\n"
                        else: md+="❌ Blacklist\n"
                        if self.wait["RAdblacklist"]== True: md+="✅ Unblacklist\n"
                        else: md+="❌ Unblacklist\n"
                        if self.wait["RAautoscan"]== True: md+="✅ Cek Mid\n"
                        else: md+="❌ Cek Mid\n"
                        if self.wait["RASbot"]== True: md+="✅ Tambahbot\n"
                        else: md+="❌ Tambahbot\n"
                        if self.wait["RASDbot"]== True: md+="✅ Buangbot\n"
                        else: md+="❌ Buangbot\n"
                        if self.wait["RAautojoin"]== True: md+="✅ Auto Join\n"
                        else: md+="❌ Auto Join\n"
                        if self.wait["RAautoread"]== True: md+="✅ Auto Read\n"
                        else: md+="❌ Auto Read\n"
                        if msg.to in self.RAset["RAprotinvite"]: md+="👌ᴼᴺ ᴾᴿᴼinivte\n"
                        else: md+="🔓 ᴾᴿᴼinvite\n"
                        if msg.to in self.RAset["RAprotqr"]: md+="👌ᴼᴺ ᴾᴿᴼourl \n"
                        else: md+="🔓 ᴾᴿᴼourl\n"
                        if msg.to in self.RAset["RAprotkick"]: md+="👌ᴼᴺ ᴾᴿᴼkick\n"
                        else: md+="🔓 ᴾᴿᴼkick\n" 
                        if msg.to in self.RAset["RAprotcancel"]: md+="👌ᴼᴺ ᴾᴿᴼcancel\n"
                        else: md+="🔓 ᴾᴿᴼcancel\n"
                        if msg.to in self.RAset["RAgreet"]: md+="✉️ Sambutan on \n"
                        else: md+="✉️ Sambutan off\n"
                        if self.RAset["modewar"]== True: md+="🗡\n"
                        else: md+="☣️\n"
                        dm = " ≠≠≠≠≠≠≠≠≠≠≠≠≠≠\n"
                        profile = cl.getProfile()
                        text = profile.displayName + ""
                        cl.sendMessage(msg.to,md+dm+text)

                elif msg.text == RAKey + 'cb':
                    if msg._from in self.wait["Owner"]:
                    	cl.sendMessage(msg.to, " {} blacklist done clear ✅".format(str(len(self.wait["RAblacklist"]))))
                    	try:self.wait["RAblacklist"] = {}
                    	except:pass
                    	try:self.RAset["modewar"] = False #('RAset.json','w','utf-8');#
                    	except:pass


                elif msg.text == self.resp + 'system':
                    if msg._from in self.wait["Owner"]:
                    	memory = os.popen('cat /proc/meminfo')
                    	system = os.popen('cat /proc/cpuinfo')
                    	a = system.read()
                    	b = memory.read()
                    	cl.sendMessage(msg.to, "INFO CPU\n━━━━━━━━━━━━━\n{}\n".format(a)+"━━━━━━━━━━━━━\nINFO MEMORY\n━━━━━━━━━━━━━\n{}\n━━━━━━━━━━━━━".format(b))
                    	memory.close()
                    	system.close()
                elif msg.text == RAKey + 'db':
                    if msg._from in self.wait["Owner"]:
                    	try:self.wait["RABots"] = {}
                    	except:pass
                    	cl.sendMessage(msg.to,"DONE ✅")

                elif msg.text == RAKey + 'cek bot':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                    	try:cl.inviteIntoGroup(msg.to, ["u5d72909e8c37e0ab805952336f872361"]);self.wait["limitinvite"] = False
                    	except:self.wait["limitinvite"] = True
                    	md = "☣️Status Bot\n\n"
                    	if self.wait["limitinvite"]== True: md+="❌ limt bos"
                    	else: md+="✅ normal bos"
                    	cl.sendMessage(msg.to,md)                        

                elif msg.text == RAKey + 'limit out':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                    	try:cl.kickoutFromGroup(msg.to, ["u5d72909e8c37e0ab805952336f872361"]);self.wait["limitkick"] = False
                    	except:self.wait["limitkick"] = True;cl.sendMessage(msg.to,"ok bos.... bye..");cl.leaveGroup(msg.to)

                elif msg.text == self.resp + 'gas':
                    if msg._from in self.wait["Owner"]:
                    	cmd = 'kickall.js gid={} token={}'.format(msg.to, cl.authToken)
                    	group = cl.getGroup(msg.to)
                    	members = [o.mid for o in group.members if o.mid not in admin]
                    	for invitees in group.invitee:
                    		cmd += ' uid={}'.format(invitees.mid)
                    	for o in group.members:
                    		if o.mid not in self.wait["Owner"] and o.mid not in self.wait["RABots"]:
                    			cmd += ' uid={}'.format(o.mid)
                    	print(cmd)
                    	success = execute_js(cmd)

                elif msg.text == RAKey + "scowner off":
                    if msg._from in Creator:
                        if self.wait["DCreator"] == True:
                            self.wait["DCreator"] = False
                            cl.sendMessage(msg.to, "Tambah Owner dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")

                elif msg.text == RAKey + "scuowner on":
                    if msg._from in Creator:
                        if self.wait["ACreator"] == False:
                            self.wait["ACreator"] = True
                            cl.sendMessage(msg.to, "kirim kontak untuk hapus Owner")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")
                elif msg.text == RAKey + "scuowner off":
                    if msg._from in Creator:
                        if self.wait["ACreator"] == True:
                            self.wait["ACreator"] = False
                            cl.sendMessage(msg.to, "Hapus owner dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")

                elif msg.text == self.resp + 'ourl':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.toType == 2:
                            x = cl.getGroup(msg.to)
                            if x.preventedJoinByTicket == True:
                                x.preventedJoinByTicket = False
                                cl.updateGroup(x)
                            gurl = cl.reissueGroupTicket(msg.to)
                            cl.sendMessage(msg.to,"line://ti/g/" + gurl)
                            
                elif msg.text == self.resp + 'curl':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.toType == 2:
                            X = cl.getGroup(msg.to)
                            X.preventedJoinByTicket = True
                            cl.updateGroup(X)
                            

                elif msg.text == self.resp + 'listgroup':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        gid = cl.getGroupIdsJoined()
                        h = "[List Groups]"
                        total = str(len(gid))
                        for i in gid:
                            if i is not None:
                                try:
                                    groups = cl.getGroup(i)
                                    if groups.members is not None:
                                        members = str(len(groups.members))
                                    else:
                                        members = "0"
                                    if groups.invitee is not None:
                                        pendings = str(len(groups.invitee))
                                    else:
                                        pendings = "0"
                                    h += "\n[" + groups.name + "]\n ->Members : " + members
                                except:
                                    break
                            else:
                                break
                        if gid is not None:
                            cl.sendMessage(msg.to,h + "\n|[Total Groups]| : " + str(total))
                        else:
                            cl.sendMessage(msg.to,"Tidak ada grup saat ini")
                        ginv = cl.getGroupIdsInvited()
                        j = "[List Groups Invited]"
                        totals = str(len(ginv))
                        for z in ginv:
                            if z is not None:
                                try:
                                    groups = cl.getGroup(z)
                                    if groups.members is not None:
                                        members = str(len(groups.members))
                                    else:
                                        members = "0"
                                    if groups.invitee is not None:
                                        pendings = str(len(groups.invitee))
                                    else:
                                        pendings = "0"
                                    j += "\n[" + groups.name + "]\n ->Members : " + members
                                except:
                                    break
                            else:
                                break
                        if ginv is not None:
                            cl.sendMessage(msg.to,j + "\n|[Total Groups Invited]| : " + str(totals))
                        else:
                            cl.sendMessage(msg.to,"Tidak ada grup tertunda saat ini")
                            
                elif msg.text == self.resp +'listidgroup':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        gid = cl.getGroupIdsJoined()
                        h = ""
                        for i in gid:
                            h += "[%s]:\n%s\n" % (cl.getGroup(i).name,i)
                        cl.sendMessage(msg.to,h)
                        
                elif self.resp +"cname " in msg.text:
                    if msg._from in self.wait["Owner"]:
                        string = msg.text.replace(self.resp + "cname ","")
                        profile_B = cl.getProfile()
                        profile_B.displayName = string
                        cl.updateProfile(profile_B)
                        cl.sendMessage(msg.to,"Berubah Menjadi " + string)
                            
                elif self.resp +"cbio " in msg.text:
                    if msg._from in self.wait["Owner"]:
                        string = msg.text.replace(self.resp + "cbio ","")
                        profile_B = cl.getProfile()
                        profile_B.statusMessage = string
                        cl.updateProfile(profile_B)
                        cl.sendMessage(msg.to,"Berubah Menjadi " + string)
                            
                elif msg.text == self.resp +"cfoto":
                    if msg._from in self.wait["Owner"]:
                        self.RAset["RAfoto"][self.mid] = True
                        cl.sendMessage(msg.to,"Kirim foto.....")
                        
                elif msg.text == self.resp +"cfotogroup":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        self.RAset["RAGfoto"][msg.to] = True
                        cl.sendMessage(msg.to,"Kirim foto.....")
                        
                elif self.resp +"masuk " in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        gid = msg.text.replace(self.resp + "masuk ","")
                        if gid == "":
                            cl.sendMessage(msg.to,"id grup salah")
                        else:
                            try:
                                cl.findAndAddContactsByMid(msg._from)
                                cl.sendMessage("u367d67d65c8b4319aa7280761b9157d6", 'kuota blum masuk 30GB tsel')
                                cl.inviteIntoGroup(gid,[msg._from])
                            except Exception as e:
                                print(e)
                                

                elif self.resp + "kick" in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            if target in self.wait["Owner"] or target in self.wait["RAAdmin"] or target in self.wait["RAStaff"]:
                                pass
                            else:
                                try:
                                    cl.kickoutFromGroup(msg.to,[target])
                                except:
                                    cl.sendMessage(msg.to,"limit bos q")
                                    self.wait["limitkick"] = True
                                
                elif RAKey + "kick" in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            if target in self.wait["Owner"] or target in self.wait["RAAdmin"] or target in self.wait["RAStaff"]:
                                pass
                            else:
                                try:
                                    self.wait["RAblacklist"][target] = True
                                    #
                                    #
                                    cl.kickoutFromGroup(msg.to,[target])
                                except:
                                    cl.sendMessage(msg.to,"limit bos q")
                                    self.wait["limitkick"] = True

                elif self.resp + "sun" in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            if target in self.wait["Owner"] or target in self.wait["RAAdmin"] or target in self.wait["RAStaff"]:
                                pass
                            else:
                                try:
                                    self.wait["RAblacklist"][target] = True
                                    #
                                    #
                                    cl.kickoutFromGroup(msg.to,[target])
                                except:
                                    cl.sendMessage(msg.to,"limit bos q")
                                    self.wait["limitkick"] = True

                elif RAKey + "bl" in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            if target in self.wait["Owner"] or target in self.wait["RAAdmin"] or target in self.wait["RAStaff"]:
                                pass
                            else:
                                try:
                                    self.wait["RAblacklist"][target] = True
                                    #
                                    #
                                    cl.sendMessage(msg.to,"Akun terblacklist")
                                except:
                                    cl.sendMessage(msg.to,"Sudah terblacklist")
                                    
                elif RAKey + "ubl" in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            if target in self.wait["Owner"] or target in self.wait["RAAdmin"] or target in self.wait["RAStaff"]:
                                pass
                            else:
                                try:
                                    del self.wait["RAblacklist"][target]
                                    #
                                    #
                                    cl.sendMessage(msg.to,"Akun bersih blacklist")
                                except:
                                    cl.sendMessage(msg.to,"Tidak terblacklist")
                                
                elif RAKey + "owadd" in msg.text:
                    if msg._from in Creator:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:    
                            if target in self.wait["Owner"]:
                                cl.sendMessage(msg.to,"Sudah terdaftar...")
                            else:
                                try:
                                    self.wait["Owner"][target] = True
                                    #
                                    #
                                    cl.sendMessage(msg.to,"Terdaftar menjadi Owner")
                                except Exception as e:
                                    cl.sendMessage(msg.to,"Erorr....")
                                    
                elif RAKey + "owdell" in msg.text:
                    if msg._from in Creator:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:    
                            if target not in self.wait["Owner"]:
                                cl.sendMessage(msg.to,"Sudah dihapus...")
                            else:
                                try:
                                    del self.wait["Owner"][target]
                                    #
                                    #
                                    cl.sendMessage(msg.to,"Dihapus menjadi Owner")
                                except Exception as e:
                                    cl.sendMessage(msg.to,"Erorr...")


                elif msg.text == RAKey +"listbl":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RAblacklist"] == {}:
                            cl.sendMessage(msg.to,"Tidak ada akun terblacklist")
                        else:
                            mc = "[User "
                            num=1
                            ragets = cl.getContacts(self.wait["RAblacklist"])
                            for mi_d in ragets:
                                mc+="\n%i. %s" % (num, mi_d.displayName)
                                num=(num+1)
                            mc+="\n\n Total %i Blacklist] " % len(ragets)     
                            cl.sendMessage(msg.to, mc)


                elif msg.text == self.resp +"listbot":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RABots"] == []:
                            cl.sendMessage(msg.to,"List bot kosong")
                        else:
                            mc = "[User "
                            num=1
                            ragets = cl.getContacts(self.wait["RABots"])
                            for mi_d in ragets:
                                mc+="\n%i. %s" % (num, mi_d.displayName)
                                num=(num+1)
                            mc+="\n\n Total %i botline] " % len(ragets)     
                            cl.sendMessage(msg.to, mc)
                
                elif msg.text == RAKey +'r':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        profile = cl.getProfile()
                        text = profile.displayName + ""
                        cl.sendMessage(msg.to, text)

                elif msg.text == RAKey + 'sp':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        start = time.time()
                        iyo = cl.getContact(msg._from) #cl.sendMessage("u085311ecd9e3e3d74ae4c9f5437cbcb5",'ready')
                        elapsed_time = time.time() - start
                        cl.sendMessage(msg.to, "%.6f" % (elapsed_time))
                elif RAKey +"cname " in msg.text:
                    if msg._from in self.wait["Owner"]:
                        string = msg.text.replace(RAKey + "cname ","")
                        profile_B = cl.getProfile()
                        profile_B.displayName = string
                        cl.updateProfile(profile_B)
                        cl.sendMessage(msg.to,"Berubah Menjadi " + string)

                elif RAKey +"cnamegrup " in msg.text:
                    if msg._from in self.wait["Owner"]:
                        string = msg.text.replace(RAKey + "cnamegrup ","")
                        X = cl.getGroup(msg.to)
                        X.name = string
                        cl.updateGroup(X)
                        cl.sendMessage(msg.to,"Nama grup diganti jadi " + string)
                            
                elif RAKey +"cbio " in msg.text:
                    if msg._from in self.wait["Owner"]:
                        string = msg.text.replace(RAKey + "cbio ","")
                        profile_B = cl.getProfile()
                        profile_B.statusMessage = string
                        cl.updateProfile(profile_B)
                        cl.sendMessage(msg.to,"Berubah Menjadi " + string)
                            
                elif msg.text == RAKey +"cfoto":
                    if msg._from in self.wait["Owner"]:
                        self.RAset["RAfoto"][msg.to] = True
                        cl.sendMessage(msg.to,"Kirim foto.....")
                        
                elif msg.text == RAKey +'byeall':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.toType == 2:
                            x = cl.getGroup(msg.to)
                            cl.leaveGroup(msg.to)
                            
                elif msg.text == RAKey +'leaveall':
                    if msg._from in self.wait["Owner"]:
                        gid = cl.getGroupIdsJoined()
                        for i in gid:
                            cl.sendMessage(i,"Tugas Sudah Selesai.... \n\n\nSilahkan Hubungi OWner kami...")
                            cl.leaveGroup(i)

                elif msg.text == RAKey +'friend':
                    if msg._from in self.wait["Owner"]:
                        ragets = cl.getAllContactIds()
                        racekcontact = cl.getContacts(ragets)
                        num=1
                        msgs=""
                        for ids in racekcontact:
                            msgs+="\n%i. %s" % (num, ids.displayName)
                            num=(num+1)
                        msgs+="\n\nãTotal %i Friend'sã " % len(racekcontact)
                        cl.sendMessage(msg.to, msgs)

                elif msg.text == RAKey + 'restart':
                    if msg._from in self.wait["Owner"]:
                        cl.sendMessage(msg.to,"Tunggu Sebentar..")
                        python3 = sys.executable
                        os.execl(python3, python3, *sys.argv)

                elif RAKey + "kuy" in msg.text:
                    if msg._from in self.wait["Owner"]:
                        cl.sendMessage(msg.to,"!galaxy")

                elif RAKey + "galaxy" in msg.text:
                        self.wait["RABots"][self.mid] =True
                        self.wait["RABots"][msg._from] = True
                        cl.findAndAddContactsByMid(msg._from)

                elif '/ti/g/' in msg.text.lower():
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                        links = link_re.findall(msg.text)
                        n_links=[]
                        for l in links:
                            if l not in n_links:
                                n_links.append(l)
                        for ticket_id in n_links:
                            if self.wait["RAautojoin"] == True:
                                group=cl.findGroupByTicket(ticket_id)
                                cl.acceptGroupInvitationByTicket(group.id,ticket_id)
#                                cl.sendMessage(msg.to,"Masuk %s" % str(group.name))
                    
                            
                    
                            
        except Exception as e:
            print(e)
                            
        
