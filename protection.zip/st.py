from client import LineBot
import json,threading,subprocess
def login(resp, auth):
	bot = LineBot(resp, auth)

Znf = threading.Thread(target=login, args=('A1','TOKEN CL 1')).start()
Znf = threading.Thread(target=login, args=('A2','TOKEN CL2')).start()
Znf = threading.Thread(target=login, args=('A3','TOKEN CL3')).start()
Znf = threading.Thread(target=login, args=('A4','TOKEN CL4')).start()
Znf = threading.Thread(target=login, args=('A5','TOKEN CL5')).start()
Znf = threading.Thread(target=login, args=('A6','TOKEN CL6')).start()
Znf = threading.Thread(target=login, args=('A7','TOKEN CL7')).start()
Znf = threading.Thread(target=login, args=('A8','TOKEN CL8')).start()
Znf = threading.Thread(target=login, args=('A9','TOKEN CL9')).start()
#Znf = threading.Thread(target=login, args=('Sm10','ud44137433d5f2bb3fb13dd120bf03005:aWF0OiAxNTY1ODQ5MzM2NDc0Cg==..WmSkVr3CuKARQjDne2bMrQ+oz8I=')).start()
#Znf = threading.Thread(target=login, args=('Fen','uc3d19ad93adf46a587dd21bc73c87a35:aWF0OiAxNTUwNDc2MTI2NzgxCg==..3iXI0RYQiLgXwCj1qg0Dwni82vY=')).start()
#Znf = threading.Thread(target=login, args=('Z12','EvExw0Vn0dJPw4XKsEx0.WbVZ1Ar5szXGYCdURkmaCa.tXEyFtNrc4/3P+ohdjzAWrMIJgvX37Sf9drY8BceI9k=')).start()
#Znf = threading.Thread(target=login, args=('Z3',4'Evx9F3Q1vw18XN2gkd12.MyJEBI/sMjpdlP4eAGqAqG.7BO+s278L1BmX+0g8vtYjCinCXRcCLKei5XPy2sP0qo=')).start()
#Znf = threading.Thread(target=login, args=('Z14','EvSD0JI3wsRJIBpTroD3.lvgoXiMV6lYaxJpXCqg4OW.ObX/r19C+ROH9Ndkewl3Ta0bmOrj0YjfKrmE5mI+IjE=')).start()
#Znf = threading.Thread(target=login, args=('Z15','EvOEFjQMh4oXUGGLJdn2.pbB/Ok82nrF+nWHt1NRwiG.pyI/2IgQ6NbGqpetwUJjzo/knrGAgm0AAEpLznicaXU=')).start()
#Znf = threading.Thread(target=login, args=('Z16','EvGnm6NKrC1iM3zfNiL8.VjxLWhxuKfLXdeFYRjOv6a.kYAj7E4OLQKZypagfvd/qdjDC3N66A65jGX4CN/5GHw=')).start()
#Znf = threading.Thread(target=login, args=('Z17','EvjYpoYHVnTF7UU9f7Ie.4Z4+vOwSG3HXMipggoRo7G.ON0muiHwOtzri+FMyqmXNbikXJkfXuKY9o04VZOI7Ng=')).start()
#Znf = threading.Thread(target=login, args=('Z8','EvOkOpbioVVYLWE8VAY9.yM2k4XRQK8D8kzXmEhQN2q.o93qFjUS+DgtWUUE7hKvRUfQxmmRVO3xNJjN53mxhxY=')).start()

#kalian bisa pagari jika kalian ingin mencoba login lebih sedikit


print('Login Berhasil!')
