from nemu import *
from thrift.ttypes import *
from multiprocessing import Pool, Process
import time, asyncio, json, threading, codecs, sys, os, re, urllib, requests, wikipedia, html5lib, timeit, pafy, youtube_dl
from bs4 import BeautifulSoup
from Naked.toolshed.shell import execute_js 
Creator = ["ud9411212b6a1f52f43c266893cd26ad4"]
RAKey = ","
mulai = time.time()

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d day %02d hour %02d min %02d sec' % (days, hours, mins, secs)
    
class LineBot(object):
    
    def __init__(self, resp, authQR=None):
        self.resp = resp
        self.resp = self.resp+' '
        self.authQR = authQR
        self.login(authQR)
        self.fetch()
        
    def login(self, auth):
        if auth == None:
            self.client = LINE()
        else:
            self.client = LINE(auth)
        #self.client_ch = LineChannel(self.client, channelId="1341209850")
        self.client.log("Auth Token : " + str(self.client.authToken))
        print("login OK")
        #self.client.log("Channel Token : " + str(self.client_ch.channelAccessToken))
        self.mid = self.client.getProfile().mid
        akun = open('RAwait.json','r')
        self.wait = json.load(akun)
        setting = open('RAset.json','r')
        self.RAset = json.load(setting)
        if self.mid not in self.wait["RABots"]:
        	self.wait["RABots"][self.mid] = True
        	f=codecs.open('RAwait.json','w','utf-8')
        	json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
        self.set = {
        	"kickall ON":False
        	}
        
        
    def fetch(self):
        while True:
            try:
                self.operations = self.client.poll.fetchOperations(self.client.revision, 10)
                for op in self.operations:
                    if (op.type != OpType.END_OF_OPERATION):
                        self.client.revision = max(self.client.revision, op.revision)
                        self.bot(op)
            except Exception:
                pass
        
    def bot(self, op):
        cl = self.client
        try:
            if op.type == 0:
                return
            
            if op.type == 19:
             if op.param3 in self.wait["RABots"]:
              if op.param2 not in self.wait["Owner"] and op.param2 not in self.wait["RAAdmin"] and op.param2 not in self.wait["RAStaff"] and op.param2 not in self.wait["RABots"]:
              	try:
              	    cl.kickoutFromGroup(op.param1,[op.param2])
              	    pasukan = self.wait["RABots"]
              	    cl.findAndAddContactsByMid(op.param3)
              	    cl.inviteIntoGroup(op.param1,pasukan)
              	    self.wait["RAblacklist"][op.param2] = True
              	    f=codecs.open('RAwait.json','w','utf-8')
              	    json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
              	except:
              	    x = cl.getGroup(op.param1)
              	    if x.preventedJoinByTicket == True:
              	        x.preventedJoinByTicket = False
              	        cl.updateGroup(x)
              	        gurl = cl.reissueGroupTicket(op.param1)
              	        cl.sendMessage(op.param3,"line://ti/g/" + gurl)
              	    else:
              	       gurl = cl.reissueGroupTicket(op.param1)
              	       cl.sendMessage(op.param3,"line://ti/g/" + gurl)
              else:
              	pasukan = self.wait["RABots"]
              	cl.findAndAddContactsByMid(op.param3)
              	cl.inviteIntoGroup(op.param1,pasukan)
             if op.param3 in self.wait["Owner"] or op.param3 in self.wait["RAAdmin"] or op.param3 in self.wait["RAStaff"]:
             	if op.param2 not in self.wait["Owner"] and op.param2 not in self.wait["RAAdmin"] and op.param2 not in self.wait["RAStaff"] and op.param2 not in self.wait["RABots"]:
             	    try:
             	        cl.kickoutFromGroup(op.param1,[op.param2])
             	        cl.findAndAddContactsByMid(op.param3)
             	        cl.inviteIntoGroup(op.param1,op.param3)
             	        self.wait["RAblacklist"][op.param2] = True
             	        f=codecs.open('RAwait.json','w','utf-8')
             	        json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
             	    except:pass
             	else:
             	    cl.findAndAddContactsByMid(op.param3)
             	    cl.inviteIntoGroup(op.param1,op.param3)

            if op.type == 11:
                if op.param1 in self.RAset["RAprotqr"]:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in self.wait["Owner"] and op.param2 not in self.wait["RAAdmin"] and op.param2 not in self.wait["RAStaff"] and op.param2 not in self.wait["RABots"]:
                            cl.reissueGroupTicket(op.param1)
                            X = cl.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            cl.updateGroup(X)
                            cl.kickoutFromGroup(op.param1,[op.param2])
                    try:
                    	if op.param2 not in self.wait["Owner"] and op.param2 not in self.wait["RAAdmin"] and op.param2 not in self.wait["RAStaff"] and op.param2 not in self.wait["RABots"]:
                    	    G = cl.getGroup(op.param1)
                    	    G.name = str(self.RAset["gname"][op.param1])
                    	    cl.updateGroup(G)
                    	    cl.kickoutFromGroup(op.param1,[op.param2])
                    except:pass
                if op.param1 in self.RAset["warmode"]:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in self.wait["Owner"] and op.param2 not in self.wait["RAAdmin"] and op.param2 not in self.wait["RAStaff"] and op.param2 not in self.wait["RABots"]:
                            cl.reissueGroupTicket(op.param1)
                            X = cl.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            cl.updateGroup(X)
                            G = cl.getGroup(op.param1)
                            G.name = str(G.name+'group kontol')
                            cl.updateGroup(G)
                            cl.kickoutFromGroup(op.param1,[op.param2])
                            self.wait["RAblacklist"][op.param2] = True
                            f=codecs.open('RAwait.json','w','utf-8')
                            json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                            try:del self.RAset["warmode"][op.param1];json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                            except:pass


            if op.type == 13:
                if self.mid in op.param3:
                    cl.acceptGroupInvitation(op.param1)
                    if self.set["kickall ON"] == True:
                    	start = time.time()
                    	cl.sendMessage("u085311ecd9e3e3d74ae4c9f5437cbcb5",'tes')
                    	elapsed_time = time.time() - start
                    	cl.sendMessage(op.param1, "Speed kick & cancel\n%.6f" % (elapsed_time))
                    	try:
                    	    cmd = 'kickall.js gid={} token={}'.format(op.param1, cl.authToken)
                    	    group = cl.getGroup(op.param1)
                    	    members = [o.mid for o in group.members if o.mid not in self.wait["Owner"] and o.mid not in self.wait["RAAdmin"] and o.mid not in self.wait["RAStaff"] and o.mid not in self.wait["RABots"]]
                    	    for invitees in group.invitee:
                    	        cmd += ' uid={}'.format(invitees.mid)
                    	except:pass
                    	for o in group.members:
                    	    if o.mid not in self.wait["Owner"] and o.mid not in self.wait["RAAdmin"] and o.mid not in self.wait["RAStaff"] and o.mid not in self.wait["RABots"]:
                    	        cmd += ' uid={}'.format(o.mid)
                    	print(cmd)
                    	success = execute_js(cmd)
            if op.type == 13:
                if op.param3 in self.wait["RAblacklist"]:
                	if op.param2 not in self.wait["Owner"] and op.param2 not in self.wait["RAAdmin"] and op.param2 not in self.wait["RAStaff"] and op.param2 not in self.wait["RABots"]:
                	 try:
                	     cl.cancelGroupInvitation(op.param1,[op.param3])
                	     cl.kickoutFromGroup(op.param1,[op.param2])
                	     cl.kickoutFromGroup(op.param1,[op.param3])
                	     self.wait["RAblacklist"][op.param2] = True
                	     f=codecs.open('RAwait.json','w','utf-8')
                	     json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                	 except:pass
                	else:
                	   cl.cancelGroupInvitation(op.param1,[op.param3])
                if op.param1 in self.RAset["RAprotinvite"]:
                    if op.param2 not in self.wait["Owner"] and op.param2 not in self.wait["RAAdmin"] and op.param2 not in self.wait["RAStaff"] and op.param2 not in self.wait["RABots"]:
                    	user = cl.getContact(op.param2)
                    	cl.cancelGroupInvitation(op.param1,[op.param3])
                    	cl.sendMessage(op.param1, "Tolong hargai Fonder dan admin kami,\njangan undang sembarangan\nmaaf km saya kick...")
                    	cl.kickoutFromGroup(op.param1,[op.param2])
                    	cl.kickoutFromGroup(op.param1,[op.param3])


            if op.type == 13:
                if self.mid in op.param3:
                    if self.wait["RAautojoin"] == True:
                    	if op.param2 in self.wait["RABots"] or op.param2 in self.wait["Owner"]:
                    	    x = cl.getGroup(op.param1)
                    	    if x.preventedJoinByTicket == True:
                    	        x.preventedJoinByTicket = False
                    	        cl.updateGroup(x)
                    	        gurl = cl.reissueGroupTicket(op.param1)
                    	        for linkqr in self.wait["RABots"]:
                    	            try:cl.sendMessage(linkqr,"line://ti/g/" + gurl)
                    	            except:pass
                    	    else:
                    	        gurl = cl.reissueGroupTicket(op.param1)
                    	        for linkqr in self.wait["RABots"]:
                    	            try:cl.sendMessage(linkqr,"line://ti/g/" + gurl)
                    	            except:pass
                    	else:
                    	    cl.acceptGroupInvitation(op.param1)
                    	    user = cl.getContact(op.param2)
                    	    cl.sendMessage(op.param1,"Anda Bukan Termasuk ADMIN/STAF...\nBye.... \n\n\n\n#Kamibukanbotgratisan.." +str(user.displayName))
                    	    cl.leaveGroup(op.param1)

                
            if op.type == 17:
                if op.param2 in self.wait["RAblacklist"]:
                    X = cl.getGroup(op.param1)
                    X.preventedJoinByTicket = True
                    cl.updateGroup(X)
                    cl.kickoutFromGroup(op.param1,[op.param2])
                    try:self.RAset["warmode"][op.param1] = True;f=codecs.open('RAset.json','w','utf-8');json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                    except:pass

            if op.type == 17:
            	if op.param1 in self.RAset["RAgreet"]:
            	    try:ginfo = cl.getGroup(op.param1);user = cl.getContact(op.param2);image = "http://dl.profile.line-cdn.net/" + user.pictureStatus;cl.sendMessage(op.param1,"Selamat datang kak " + str(user.displayName) +"\ndi room " + str(ginfo.name) + "\njgn lupa cek note setiap saat yah.. Dilarang keras mengundang orang lain kecuali Penyelenggara, Membuka Kode QR dan share sesuatu yg berbau pornografi.. \n\nTrimakasih " + str(user.displayName))
            	    except:pass
            if op.type == 19:
                if op.param1 in self.RAset["RAprotkick"]:
                    if op.param2 not in self.wait["Owner"] and op.param2 not in self.wait["RAAdmin"] and op.param2 not in self.wait["RAStaff"] and op.param2 not in self.wait["RABots"]:
                        self.wait["RAblacklist"][op.param2] = True
                        f=codecs.open('RAwait.json','w','utf-8')
                        json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                        user = cl.getContact(op.param2)
                        cl.sendMessage(op.param1,"jangan sembarangan kick orang, \nmaaf anda saya Tendang" + str(user.displayName))
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        try:
                            cl.findAndAddContactsByMid(op.param3)
                            cl.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            pass
                

            if op.type == 32:
                if op.param1 in self.RAset["RAprotcancel"]:
                    if op.param2 not in self.wait["Owner"] and op.param2 not in self.wait["RAAdmin"] and op.param2 not in self.wait["RAStaff"] and op.param2 not in self.wait["RABots"]:
                        cl.kickoutFromGroup(op.param1,[op.param2])
                        self.wait["RAblacklist"][op.param2] = True
                        f=codecs.open('RAwait.json','w','utf-8')
                        json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                        try:
                            if op.param3 not in self.wait["RAblacklist"]:
                                cl.findAndAddContactsByMid(op.param3)
                                cl.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            if op.param3 not in self.wait["RAblacklist"]:
                                cl.findAndAddContactsByMid(op.param3)
                                cl.inviteIntoGroup(op.param1,[op.param3])
            
            if op.type == 46:
                if op.param2 in self.wait["RABots"]:
                    cl.removeAllMessages()
                
            if op.type == 55:
                if op.param1 in self.RAset["RAreadPoint"]:
                    if op.param2 in self.RAset["RAreadMember"][op.param1]:
                        pass
                    else:
                        self.RAset["RAreadMember"][op.param1][op.param2] = True
                else:
                    pass
                
            if op.type == 26:
                msg = op.message
                if msg.to in self.RAset["RAreadPoint"]:
                    if msg._from in self.RAset["RAreadMember"][msg.to]:
                        pass
                    else:
                        self.RAset["RAreadMember"][msg.to][msg._from] = True
                else:
                    pass
            
            if op.type == 26:
                if self.wait["RAautoread"] == True:
                    msg = op.message
                    if msg.toType == 2:
                        msg.to = msg.to
                        cl.sendChatChecked(msg.to,msg.id)

            if op.type == 26:
                msg = op.message
                
                
                if msg.contentType == 13:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RAwblacklist"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RAblacklist"]:
                                cl.sendMessage(msg.to,"Akun sudah terblacklist")
                            else:
                                self.wait["RAblacklist"][msg.contentMetadata["mid"]] = True
                                f=codecs.open('RAwait.json','w','utf-8')
                                json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendMessage(msg.to,"Akun terblacklist")
                        elif self.wait["RAdblacklist"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RAblacklist"]:
                                del self.wait["RAblacklist"][msg.contentMetadata["mid"]]
                                f=codecs.open('RAwait.json','w','utf-8')
                                json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendMessage(msg.to,"Akun dihapus dari blacklist")
                            else:
                                cl.sendMessage(msg.to,"Akun tidak ada di blacklist")
                        elif self.wait["RAautoscan"] == True:
                            msg.contentType = 0
                            cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                            
                    if msg._from in Creator or msg._from in self.wait["Owner"]:         
                        if self.wait["DCreator"] == True:
                            if msg.contentMetadata["mid"] in self.wait["Owner"]:
                                cl.sendMessage(msg.to,"Akun sudah menjadi owner")
                            else:
                                self.wait["Owner"][msg.contentMetadata["mid"]] = True
                                f=codecs.open('RAwait.json','w','utf-8')
                                json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendMessage(msg.to,"Terdaftar menjadi Owner")
                        elif self.wait["ACreator"] == True:
                            if msg.contentMetadata["mid"] in self.wait["Owner"]:
                                del self.wait["Owner"][msg.contentMetadata["mid"]]
                                f=codecs.open('RAwait.json','w','utf-8')
                                json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendMessage(msg.to,"Akun dihapus dari Ownerlist")
                            else:
                                cl.sendMessage(msg.to,"Akun tidak ada di Ownerlist")
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:         
                        if self.wait["GLOwner"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RAAdmin"]:
                                cl.sendMessage(msg.to,"Akun sudah menjadi admin")
                            else:
                                self.wait["RAAdmin"][msg.contentMetadata["mid"]] = True
                                f=codecs.open('RAwait.json','w','utf-8')
                                json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendMessage(msg.to,"Terdaftar menjadi admin")
                        elif self.wait["RASDadmin"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RAAdmin"]:
                                del self.wait["RAAdmin"][msg.contentMetadata["mid"]]
                                f=codecs.open('RAwait.json','w','utf-8')
                                json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendMessage(msg.to,"Akun dihapus dari adminlist")
                            else:
                                cl.sendMessage(msg.to,"Akun tidak ada di adminlist")
                        elif self.wait["RASstaff"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RAStaff"]:
                                cl.sendMessage(msg.to,"Akun sudah menjadi staff")
                            else:
                                self.wait["RAStaff"][msg.contentMetadata["mid"]] = True
                                f=codecs.open('RAwait.json','w','utf-8')
                                json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendMessage(msg.to,"Terdaftar menjadi staff")
                        elif self.wait["RASDstaff"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RAStaff"]:
                                del self.wait["RAStaff"][msg.contentMetadata["mid"]]
                                f=codecs.open('RAwait.json','w','utf-8')
                                json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendMessage(msg.to,"Akun dihapus dari stafflist")
                            else:
                                cl.sendMessage(msg.to,"Akun tidak ada di stafflist")
                                
                    if msg._from in self.wait["Owner"]:
                        if self.wait["RASbot"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RABots"]:
                                cl.sendMessage(msg.to,"Bot sudah masuk list")
                            else:
                                self.wait["RABots"][msg.contentMetadata["mid"]] = True
                                f=codecs.open('RAwait.json','w','utf-8')
                                json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendMessage(msg.to,"Bot masuk dalam list")
                        elif self.wait["RASDbot"] == True:
                            if msg.contentMetadata["mid"] in self.wait["RABots"]:
                                del self.wait["RABots"][msg.contentMetadata["mid"]]
                                f=codecs.open('RAwait.json','w','utf-8')
                                json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendMessage(msg.to,"Bot keluar dari list")
                            else:
                                cl.sendMessage(msg.to,"Bot tidak ada di list")
                    
                elif msg.contentType == 1:
                    if msg._from in self.wait["Owner"]:
                        if self.mid in self.RAset["RAfoto"]:
                            path = cl.downloadObjectMsg(msg.id)
                            del self.RAset["RAfoto"][self.mid]
                            cl.updateProfilePicture(path)
                            cl.sendMessage(msg.to,"Foto berhasil dirubah")
                        elif msg.to in self.RAset["RAfoto"]:
                            path = cl.downloadObjectMsg(msg.id)
                            cl.updateProfilePicture(path)
                            del self.RAset["RAfoto"][msg.to]
                            cl.sendMessage(msg.to,"Foto berhasil diperbaharui")
                        if msg.toType == 2:
                            if msg.to in self.RAset["RAGfoto"]:
                                path = cl.downloadObjectMsg(msg.id)
                                del self.RAset["RAGfoto"][msg.to]
                                cl.updateGroupPicture(msg.to, path)
                                cl.sendMessage(msg.to,"Foto grup diperbaharui")
                elif None == msg.text:
                    return
                
#------------------------------- Start Menu ----------------------------------#
            
                elif msg.text == self.resp + 'men':
                    if msg._from in self.wait["Owner"]:
                        md = "╭━━━━━━━━━━━━━╮\n┃♦️🔵T̘̟̼̉̈́͐͋͌̊e̮̟͈̣̖̰̩̹͈̾ͨ̑͑a̘̫͈̭͌͛͌̇̇̍m̘͈̺̪͓ͩ͂̾ͪ̀̋b͎̣̫͈̥͒͌̃͑̔̾ͅo̜̓̇ͫ̉͊ͨt̘̟̼̉̈́͐͋͌̊a̘̫͈͌͛͌̇̇̍m̘͈̺̪͓̺ͩ͂̾ͪ̀̋a̘̫͈͌͛͌̇̇̍t̘̟̼̉̈́͐͋͌̊i̞̟̫̺ͭ̒ͭͣr̼̯̤̗̲̞̥̈ͭ̃ͨ̆a̘̫͈̭͌͛͌̇̇̍n͉̠̙͉̗̺̋̔ͧ̊🔵♦️\n╰━━━━━━━━━━━━━╯\n──┅━✥ ======= ✥━┅──\n                 作者指令 \n──┅━✥ ======= ✥━┅──\n╭━━━━━━━━━━━━━╮\n"
                        md += "┃☬┃" +RAKey+ "absen\n"
                        md += "┃☬┃" +RAKey+ "sp\n"
                        md += "┃☬┃" +RAKey+ "sprespon\n"
                        md += "┃☬┃" +RAKey+ "cname [text]\n"
                        md += "┃☬┃" +RAKey+ "cbio [text]\n"
                        md += "┃☬┃" +RAKey+ "cfoto\n"
                        md += "┃☬┃" +RAKey+ "cleanblacklist\n"
                        md += "┃☬┃" +RAKey+ "byeall\n"
                        md += "┃☬┃" +RAKey+ "leaveallgroup\n"
                        md += "┃☬┃" +RAKey+ "gas\n"
                        md += "┃☬┃" +RAKey+ "friend\n"
                        md += "┃☬┃" +RAKey+ "spam[mid][jumlah]\n"
                        md += "┃☬┃" +RAKey+ "restart\n"
                        md += "┃☬┃" +RAKey+ "masukin\n"
                        md += "┃☬┃" +RAKey+ "removechat\n"
                        md += "┃☬┃" +RAKey+ "keluar [namagroup]\n"
                        md += "┃☬┃" +RAKey+ "scblack [on/off]\n"
                        md += "┃☬┃" +RAKey+ "scublack [on/off]\n"
                        md += "┃☬┃" +RAKey+ "scadmin [on/off]\n"
                        md += "┃☬┃" +RAKey+ "scuadmin [on/off]\n"
                        md += "┃☬┃" +RAKey+ "scstaff [on/off]\n"
                        md += "┃☬┃" +RAKey+ "scustaff [on/off]\n"
                        md += "┃☬┃" +RAKey+ "autoread [on/off]\n"
                        md += "┃☬┃" +RAKey+ "ngebot [on/off]\n"
                        md += "┃☬┃" +RAKey+ "buangbot [on/off]\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] invite\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] ourl\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] cancel\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] kick\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] all\n"
                        md += "┃☬┃" +RAKey+ "mspam\n"
                        md += "┃☬┃" +RAKey+ "cspam[text]\n"
                        md += "┃☬┃" +RAKey+ "bl [@target]\n"
                        md += "┃☬┃" +RAKey+ "ubl [@target]\n"
                        md += "┃☬┃" +RAKey+ "adadd [@target]\n"
                        md += "┃☬┃" +RAKey+ "addell [@target]\n"
                        md += "┃☬┃" +RAKey+ "stadd [@target]\n"
                        md += "┃☬┃" +RAKey+ "stdell [@target]\n"
                        md += "┃☬┃" +RAKey+ "tbot [@target]\n"
                        md += "┃☬┃" +RAKey+ "cuekinbot [@target]\n"
                        md += "┃☬┃" +RAKey+ "cb [clearban]\n"
                        md += "╰━━━━━━━━━━━━━╯\n──┅━✥ ======= ✥━┅──\n                 FOR  ALLBOT\n──┅━✥ ======= ✥━┅──\n╭━━━━━━━━━━━━━╮\n"
                        md += "┃☬┃" +self.resp+ "set\n"
                        md += "┃☬┃" +self.resp+ "cekmid [on/off]\n"
                        md += "┃☬┃" +self.resp+ "wellcome [on/off]\n"
                        md += "┃☬┃" +self.resp+ "ourl / curl\n"
                        md += "┃☬┃" +self.resp+ "informasi\n"
                        md += "┃☬┃" +self.resp+ "listgroup\n"
                        md += "┃☬┃" +self.resp+ "listidgroup\n"
                        md += "┃☬┃" +self.resp+ "cname [text]\n"
                        md += "┃☬┃" +self.resp+ "cbio [text]\n"
                        md += "┃☬┃" +self.resp+ "cfoto\n"
                        md += "┃☬┃" +self.resp+ "cfotogroup\n"
                        md += "┃☬┃" +self.resp+ "cancel\n"
                        md += "┃☬┃" +self.resp+ "masuk [idgroup]\n"
                        md += "┃☬┃" +self.resp+ "bc [text]\n"
                        md += "┃☬┃" +self.resp+ "kick  [@target]\n"
                        md += "┃☬┃" +self.resp+ "listbl\n"
                        md += "┃☬┃" +self.resp+ "limit [jumlah]\n"
                        md += "┃☬┃" +self.resp+ "panggil  [@target]\n"
                        md += "┃☬┃" +self.resp+ "listteam\n"
                        md += "┃☬┃" +self.resp+ "listbot\n"
                        md += "┃☬┃" +self.resp+ "listprotect\n"
                        md += "╰━━━━━━━━━━━━━╯\n──┅━✥ ======= ✥━┅──\n                 FOR  ONE BOT\n──┅━✥ ======= ✥━┅──\n╭━━━━━━━━━━━━━╮\n┃      🇮🇩T̘̟̼̉̈́͐͋͌̊e̮̟͈̣̖̰̩̹͈̾ͨ̑͑a̘̫͈̭͌͛͌̇̇̍m̘͈̺̪͓ͩ͂̾ͪ̀̋b͎̣̫͈̥͒͌̃͑̔̾ͅo̜̓̇ͫ̉͊ͨt̘̟̼̉̈́͐͋͌̊a̘̫͈͌͛͌̇̇̍m̘͈̺̪͓̺ͩ͂̾ͪ̀̋a̘̫͈͌͛͌̇̇̍t̘̟̼̉̈́͐͋͌̊i̞̟̫̺ͭ̒ͭͣr̼̯̤̗̲̞̥̈ͭ̃ͨ̆a̘̫͈̭͌͛͌̇̇̍n͉̠̙͉̗̺̋̔ͧ̊🇮🇩     ┃\n╰━━━━━━━━━━━━━╯\n"
                        cl.sendMessage(msg.to,md)
                        
                elif msg.text == self.resp + 'admin':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        md = "╭━━━━━━━━━━━━━╮\n┃♦️🔵T̘̟̼̉̈́͐͋͌̊e̮̟͈̣̖̰̩̹͈̾ͨ̑͑a̘̫͈̭͌͛͌̇̇̍m̘͈̺̪͓ͩ͂̾ͪ̀̋b͎̣̫͈̥͒͌̃͑̔̾ͅo̜̓̇ͫ̉͊ͨt̘̟̼̉̈́͐͋͌̊a̘̫͈͌͛͌̇̇̍m̘͈̺̪͓̺ͩ͂̾ͪ̀̋a̘̫͈͌͛͌̇̇̍t̘̟̼̉̈́͐͋͌̊i̞̟̫̺ͭ̒ͭͣr̼̯̤̗̲̞̥̈ͭ̃ͨ̆a̘̫͈̭͌͛͌̇̇̍n͉̠̙͉̗̺̋̔ͧ̊🔵♦️\n╰━━━━━━━━━━━━━╯\n──┅━✥ ======= ✥━┅──\n                 SPECIAL  ADMIN\n──┅━✥ ======= ✥━┅──\n╭━━━━━━━━━━━━━╮\n"
                        md += "┃☬┃" +RAKey+ "absen\n"
                        md += "┃☬┃" +RAKey+ "sp\n"
                        md += "┃☬┃" +RAKey+ "sprespon\n"
                        md += "┃☬┃" +RAKey+ "cleanblacklist\n"
                        md += "┃☬┃" +RAKey+ "byeall\n"
                        md += "┃☬┃" +RAKey+ "scblack [on/off]\n"
                        md += "┃☬┃" +RAKey+ "scublack [on/off]\n"
                        md += "┃☬┃" +RAKey+ "scstaff [on/off]\n"
                        md += "┃☬┃" +RAKey+ "scustaff [on/off]\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] invite\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] ourl\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] cancel\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] kick\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] all\n"
                        md += "┃☬┃" +RAKey+ "spam[mid][jumlah]\n"
                        md += "┃☬┃" +RAKey+ "mspam\n"
                        md += "┃☬┃" +RAKey+ "cspam[text]\n"
                        md += "┃☬┃" +RAKey+ "bl [@target]\n"
                        md += "┃☬┃" +RAKey+ "ubl [@target]\n"
                        md += "┃☬┃" +RAKey+ "stadd [@target]\n"
                        md += "┃☬┃" +RAKey+ "stdell [@target]\n"
                        md += "╰━━━━━━━━━━━━━╯\n──┅━✥ ======= ✥━┅──\n                 FOR  ALL BOT\n──┅━✥ ======= ✥━┅──\n╭━━━━━━━━━━━━━╮\n"
                        md += "┃☬┃" +self.resp+ "set\n"
                        md += "┃☬┃" +self.resp+ "cekmid [on/off]\n"
                        md += "┃☬┃" +self.resp+ "wellcome [on/off]\n"
                        md += "┃☬┃" +self.resp+ "ourl / curl\n"
                        md += "┃☬┃" +self.resp+ "informasi\n"
                        md += "┃☬┃" +self.resp+ "listgroup\n"
                        md += "┃☬┃" +self.resp+ "listidgroup\n"
                        md += "┃☬┃" +self.resp+ "cfotogroup\n"
                        md += "┃☬┃" +self.resp+ "cancel\n"
                        md += "┃☬┃" +self.resp+ "masuk[idgroup]\n"
                        md += "┃☬┃" +self.resp+ "bc[text]\n"
                        md += "┃☬┃" +self.resp+ "kick [@target]\n"
                        md += "┃☬┃" +self.resp+ "listbl\n"
                        md += "┃☬┃" +self.resp+ "listteam\n"
                        md += "┃☬┃" +self.resp+ "listbot\n"
                        md += "┃☬┃" +self.resp+ "listprotect\n"
                        md += "╰━━━━━━━━━━━━━╯\n──┅━✥ ======= ✥━┅──\n                 FOR  ONE BOT\n──┅━✥ ======= ✥━┅──\n╭━━━━━━━━━━━━━╮\n┃      🇮🇩T̘̟̼̉̈́͐͋͌̊e̮̟͈̣̖̰̩̹͈̾ͨ̑͑a̘̫͈̭͌͛͌̇̇̍m̘͈̺̪͓ͩ͂̾ͪ̀̋b͎̣̫͈̥͒͌̃͑̔̾ͅo̜̓̇ͫ̉͊ͨt̘̟̼̉̈́͐͋͌̊a̘̫͈͌͛͌̇̇̍m̘͈̺̪͓̺ͩ͂̾ͪ̀̋a̘̫͈͌͛͌̇̇̍t̘̟̼̉̈́͐͋͌̊i̞̟̫̺ͭ̒ͭͣr̼̯̤̗̲̞̥̈ͭ̃ͨ̆a̘̫͈̭͌͛͌̇̇̍n͉̠̙͉̗̺̋̔ͧ̊🇮🇩     ┃\n╰━━━━━━━━━━━━━╯\n"
                        cl.sendMessage(msg.to,md)
                        
                elif msg.text == self.resp + 'staff':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        md = "╭━━━━━━━━━━━━━╮\n┃♦️🔵T̘̟̼̉̈́͐͋͌̊e̮̟͈̣̖̰̩̹͈̾ͨ̑͑a̘̫͈̭͌͛͌̇̇̍m̘͈̺̪͓ͩ͂̾ͪ̀̋b͎̣̫͈̥͒͌̃͑̔̾ͅo̜̓̇ͫ̉͊ͨt̘̟̼̉̈́͐͋͌̊a̘̫͈͌͛͌̇̇̍m̘͈̺̪͓̺ͩ͂̾ͪ̀̋a̘̫͈͌͛͌̇̇̍t̘̟̼̉̈́͐͋͌̊i̞̟̫̺ͭ̒ͭͣr̼̯̤̗̲̞̥̈ͭ̃ͨ̆a̘̫͈̭͌͛͌̇̇̍n͉̠̙͉̗̺̋̔ͧ̊🔵♦️\n╰━━━━━━━━━━━━━╯\n──┅━✥ ======= ✥━┅──\n                 SPECIAL  STAFF \n──┅━✥ ======= ✥━┅──\n╭━━━━━━━━━━━━━╮\n"
                        md += "┃☬┃" +RAKey+ "absen\n"
                        md += "┃☬┃" +RAKey+ "sp\n"
                        md += "┃☬┃" +RAKey+ "sprespon\n"
                        md += "┃☬┃" +RAKey+ "cleanblacklist\n"
                        md += "┃☬┃" +RAKey+ "byeall\n"
                        md += "┃☬┃" +RAKey+ "scblack [on/off]\n"
                        md += "┃☬┃" +RAKey+ "scublack [on/off]\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] invite\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] ourl\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] cancel\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] kick\n"
                        md += "┃☬┃" +RAKey+ "[lock/unlock] all\n"
                        md += "┃☬┃" +RAKey+ "bl [@target]\n"
                        md += "┃☬┃" +RAKey+ "ubl [@target]\n"
                        md += "╰━━━━━━━━━━━━━╯\n──┅━✥ ======= ✥━┅──\n                 FOR  ALLBOT\n──┅━✥ ======= ✥━┅──\n╭━━━━━━━━━━━━━╮\n"
                        md += "┃☬┃" +self.resp+ "set\n"
                        md += "┃☬┃" +self.resp+ "cekmid [on/off]\n"
                        md += "┃☬┃" +self.resp+ "wellcome [on/off]\n"
                        md += "┃☬┃" +self.resp+ "ourl / curl\n"
                        md += "┃☬┃" +self.resp+ "informasi\n"
                        md += "┃☬┃" +self.resp+ "listgroup\n"
                        md += "┃☬┃" +self.resp+ "cancel\n"
                        md += "┃☬┃" +self.resp+ "kick [@target]\n"
                        md += "┃☬┃" +self.resp+ "listbl\n"
                        md += "┃☬┃" +self.resp+ "listteam\n"
                        md += "┃☬┃" +self.resp+ "listbot\n"
                        md += "╰━━━━━━━━━━━━━╯\n──┅━✥ ======= ✥━┅──\n                 FOR ONE BOT\n──┅━✥ ======= ✥━┅──\n╭━━━━━━━━━━━━━╮\n┃      🇮🇩T̘̟̼̉̈́͐͋͌̊e̮̟͈̣̖̰̩̹͈̾ͨ̑͑a̘̫͈̭͌͛͌̇̇̍m̘͈̺̪͓ͩ͂̾ͪ̀̋b͎̣̫͈̥͒͌̃͑̔̾ͅo̜̓̇ͫ̉͊ͨt̘̟̼̉̈́͐͋͌̊a̘̫͈͌͛͌̇̇̍m̘͈̺̪͓̺ͩ͂̾ͪ̀̋a̘̫͈͌͛͌̇̇̍t̘̟̼̉̈́͐͋͌̊i̞̟̫̺ͭ̒ͭͣr̼̯̤̗̲̞̥̈ͭ̃ͨ̆a̘̫͈̭͌͛͌̇̇̍n͉̠̙͉̗̺̋̔ͧ̊🇮🇩     ┃\n╰━━━━━━━━━━━━━╯\n"
                        cl.sendMessage(msg.to,md)
                        
                elif msg.text == self.resp + 'publik':
                    md = "╭━━━━━━━━━━━━━╮\n┃♦️🔵T̘̟̼̉̈́͐͋͌̊e̮̟͈̣̖̰̩̹͈̾ͨ̑͑a̘̫͈̭͌͛͌̇̇̍m̘͈̺̪͓ͩ͂̾ͪ̀̋b͎̣̫͈̥͒͌̃͑̔̾ͅo̜̓̇ͫ̉͊ͨt̘̟̼̉̈́͐͋͌̊a̘̫͈͌͛͌̇̇̍m̘͈̺̪͓̺ͩ͂̾ͪ̀̋a̘̫͈͌͛͌̇̇̍t̘̟̼̉̈́͐͋͌̊i̞̟̫̺ͭ̒ͭͣr̼̯̤̗̲̞̥̈ͭ̃ͨ̆a̘̫͈̭͌͛͌̇̇̍n͉̠̙͉̗̺̋̔ͧ̊🔵♦️\n╰━━━━━━━━━━━━━╯\n──┅━✥ ======= ✥━┅──\n                 SPECIAL  PUBLIC \n──┅━✥ ======= ✥━┅──\n╭━━━━━━━━━━━━━╮\n"
                    md += "┃☬┃" +self.resp+ "cek [@target]\n"
                    md += "┃☬┃" +self.resp+ "gid\n"
                    md += "┃☬┃" +self.resp+ "yid\n"
                    md += "┃☬┃" +self.resp+ "cctv[on/off][cyduk]\n"
                    md += "┃☬┃" +self.resp+ "tagall\n"
                    md += "┃☬┃" +self.resp+ "yt-video[nama-judul]\n"
                    md += "┃☬┃" +self.resp+ "yt-mp3[nama-judul]\n"
                    md += "┃☬┃" +self.resp+ "film [judul] [tahun]\n"
                    md += "┃☬┃" +self.resp+ "get-ig [username]\n"
                    md += "┃☬┃" +self.resp+ "igpost [user] [list]\n"
                    md += "┃☬┃" +self.resp+ "wsholat [nama lokasi]\n"
                    md += "┃☬┃" +self.resp+ "ccuaca [nama lokasi]\n"
                    md += "┃☬┃" +self.resp+ "clokasi [nama lokasi]\n"
                    md += "╰━━━━━━━━━━━━━╯\n──┅━✥ ======= ✥━┅──\n                 SPECIAL  PUBLIC\n──┅━✥ ======= ✥━┅──\n╭━━━━━━━━━━━━━╮\n┃      🇮🇩T̘̟̼̉̈́͐͋͌̊e̮̟͈̣̖̰̩̹͈̾ͨ̑͑a̘̫͈̭͌͛͌̇̇̍m̘͈̺̪͓ͩ͂̾ͪ̀̋b͎̣̫͈̥͒͌̃͑̔̾ͅo̜̓̇ͫ̉͊ͨt̘̟̼̉̈́͐͋͌̊a̘̫͈͌͛͌̇̇̍m̘͈̺̪͓̺ͩ͂̾ͪ̀̋a̘̫͈͌͛͌̇̇̍t̘̟̼̉̈́͐͋͌̊i̞̟̫̺ͭ̒ͭͣr̼̯̤̗̲̞̥̈ͭ̃ͨ̆a̘̫͈̭͌͛͌̇̇̍n͉̠̙͉̗̺̋̔ͧ̊🇮🇩     ┃\n╰━━━━━━━━━━━━━╯"
                    cl.sendMessage(msg.to,md)
                    
                elif msg.text == self.resp + 'set':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        md = "☣️Status setting\n ≠≠≠≠≠≠≠≠≠≠≠≠≠≠\n"
                        if self.set["kickall ON"]== True: md+="Mode kickall 🔛\n"
                        else: md+="Mode kickall 📴\n"
                        if self.wait["GLOwner"]== True: md+="✅ Add Admin\n"
                        else: md+="❌ Add Admin\n"
                        if self.wait["RASDadmin"]== True: md+="✅ Dell Admin\n"
                        else: md+="❌ Dell Admin\n"
                        if self.wait["RASstaff"]== True: md+="✅ Add Staff\n"
                        else: md+="❌ Add Staff\n"
                        if self.wait["RASDstaff"]== True: md+="✅ Dell Staff\n"
                        else: md+="❌ Dell Staff\n"
                        if self.wait["RAwblacklist"]== True: md+="✅ Blacklist\n"
                        else: md+="❌ Blacklist\n"
                        if self.wait["RAdblacklist"]== True: md+="✅ Unblacklist\n"
                        else: md+="❌ Unblacklist\n"
                        if self.wait["RAautoscan"]== True: md+="✅ Cek Mid\n"
                        else: md+="❌ Cek Mid\n"
                        if self.wait["RASbot"]== True: md+="✅ Tambahbot\n"
                        else: md+="❌ Tambahbot\n"
                        if self.wait["RASDbot"]== True: md+="✅ Buangbot\n"
                        else: md+="❌ Buangbot\n"
                        if self.wait["RAautojoin"]== True: md+="✅ Auto Join\n"
                        else: md+="❌ Auto Join\n"
                        if self.wait["RAautoread"]== True: md+="✅ Auto Read\n"
                        else: md+="❌ Auto Read\n"
                        if msg.to in self.RAset["RAprotinvite"]: md+="👌ᴼᴺ ᴾᴿᴼinivte\n"
                        else: md+="🔓 ᴾᴿᴼinvite\n"
                        if msg.to in self.RAset["RAprotqr"]: md+="👌ᴼᴺ ᴾᴿᴼourl \n"
                        else: md+="🔓 ᴾᴿᴼourl\n"
                        if msg.to in self.RAset["RAprotkick"]: md+="👌ᴼᴺ ᴾᴿᴼkick\n"
                        else: md+="🔓 ᴾᴿᴼkick\n" 
                        if msg.to in self.RAset["RAprotcancel"]: md+="👌ᴼᴺ ᴾᴿᴼcancel\n"
                        else: md+="🔓 ᴾᴿᴼcancel\n"
                        if msg.to in self.RAset["RAgreet"]: md+="✉️ Sambutan on \n"
                        else: md+="✉️ Sambutan off\n"
                        if msg.to in self.RAset["warmode"]: md+="                    ⚔\n"
                        else: md+="                       🔰\n"
                        dm = " ≠≠≠≠≠≠≠≠≠≠≠≠≠≠\n"
                        profile = cl.getProfile()
                        text = profile.displayName + ""
                        cl.sendMessage(msg.to,md+dm+text)

                elif msg.text == RAKey + 'cb':
                    if msg._from in self.wait["Owner"]:
                    	try:self.wait["RAblacklist"] = {};f=codecs.open('RAwait.json','w','utf-8');json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                    	except:pass
                    	try:self.RAset["warmode"] = {};f=codecs.open('RAset.json','w','utf-8');json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                    	except:pass
                    	cl.sendMessage(msg.to,"DONE ✅")

                elif msg.text == RAKey + 'adbot':
                    if msg._from in self.wait["Owner"]:
                    	try:self.wait["RABots"].append(self.mid);f=codecs.open('RAwait.json','w','utf-8');json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                    	except:pass
                    	cl.sendMessage(msg.to," ✅")
                    	
                elif msg.text == RAKey + 'db':
                    if msg._from in self.wait["Owner"]:
                    	try:self.wait["RABots"] = {};f=codecs.open('RAwait.json','w','utf-8');json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                    	except:pass
                    	cl.sendMessage(msg.to,"DONE ✅")

                elif msg.text == RAKey + 'cek bot':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                    	try:cl.inviteIntoGroup(msg.to, ["u5d72909e8c37e0ab805952336f872361"]);self.wait["limitinvite"] = False
                    	except:self.wait["limitinvite"] = True
                    	md = "☣️Status Bot\n\n"
                    	if self.wait["limitinvite"]== True: md+="Status limt bos\n"
                    	else: md+="Status normal bos\n"
                    	cl.sendMessage(msg.to,md)                        

                elif msg.text == RAKey + 'limit out':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                    	try:cl.kickoutFromGroup(msg.to, ["u5d72909e8c37e0ab805952336f872361"]);self.wait["limitkick"] = False
                    	except:self.wait["limitkick"] = True;cl.sendMessage(msg.to,"ok bos.... bye..");cl.leaveGroup(msg.to)
                
                elif msg.text == RAKey + "scblack on":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RAwblacklist"] == False:
                            self.wait["RAwblacklist"] = True
                            cl.sendMessage(msg.to, "kirim kontak untuk blacklist")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")

                elif msg.text == RAKey + "kicker on":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.set["kickall ON"] == False:
                            self.set["kickall ON"] = True
                            cl.sendMessage(msg.to, "Mode kicker ON\nPlease invite me to room target")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")

                elif msg.text == RAKey + "kicker off":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.set["kickall ON"] == True:
                            self.set["kickall ON"] = False
                            cl.sendMessage(msg.to, "Kicker off")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")

                elif msg.text == self.resp + "kicker on":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.set["kickall ON"] == False:
                            self.set["kickall ON"] = True
                            cl.sendMessage(msg.to, "Mode kicker ON\nPlease invite me to room target")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")

                elif msg.text == self.resp + "kicker off":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.set["kickall ON"] == True:
                            self.set["kickall ON"] = False
                            cl.sendMessage(msg.to, "Kicker off")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")
                            
                elif msg.text == RAKey + "scblack off":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RAwblacklist"] == True:
                            self.wait["RAwblacklist"] = False
                            cl.sendMessage(msg.to, "Blacklist dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")
                            
                elif msg.text == RAKey + "scublack on":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RAdblacklist"] == False:
                            self.wait["RAdblacklist"] = True
                            cl.sendMessage(msg.to, "kirim kontak untuk unblacklist")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")
                            
                elif msg.text == RAKey + "join off":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RAautojoin"] == True:
                            self.wait["RAautojoin"] = False
                            cl.sendMessage(msg.to, "auto join tidak aktif")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")
                            
                elif msg.text == RAKey + "join on":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RAautojoin"] == False:
                            self.wait["RAautojoin"] = True
                            cl.sendMessage(msg.to, "auto join aktif")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")
                            
                elif msg.text == RAKey + "scublack off":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RAdblacklist"] == True:
                            self.wait["RAdblacklist"] = False
                            cl.sendMessage(msg.to, "Unblacklist dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")
                elif msg.text == RAKey + "scadmin on":
                    if msg._from in self.wait["Owner"]:
                        if self.wait["GLOwner"] == False:
                            self.wait["GLOwner"] = True
                            cl.sendMessage(msg.to, "kirim kontak untuk tambah admin")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")
                            
                elif msg.text == RAKey + "scadmin off":
                    if msg._from in self.wait["Owner"]:
                        if self.wait["GLOwner"] == True:
                            self.wait["GLOwner"] = False
                            cl.sendMessage(msg.to, "Tambah admin dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")
                            
                elif msg.text == RAKey + "scowner on":
                    if msg._from in Creator:
                        if self.wait["DCreator"] == False:
                            self.wait["DCreator"] = True
                            cl.sendMessage(msg.to, "kirim kontak untuk tambah Owner")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")
                            
                elif msg.text == RAKey + "scowner off":
                    if msg._from in Creator:
                        if self.wait["DCreator"] == True:
                            self.wait["DCreator"] = False
                            cl.sendMessage(msg.to, "Tambah Owner dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")

                elif msg.text == RAKey + "scuowner on":
                    if msg._from in Creator:
                        if self.wait["ACreator"] == False:
                            self.wait["ACreator"] = True
                            cl.sendMessage(msg.to, "kirim kontak untuk hapus Owner")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")
                elif msg.text == RAKey + "scuowner off":
                    if msg._from in Creator:
                        if self.wait["ACreator"] == True:
                            self.wait["ACreator"] = False
                            cl.sendMessage(msg.to, "Hapus owner dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")
                elif msg.text == RAKey + "scuadmin on":
                    if msg._from in self.wait["Owner"]:
                        if self.wait["RASDadmin"] == False:
                            self.wait["RASDadmin"] = True
                            cl.sendMessage(msg.to, "kirim kontak untuk hapus admin")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")
                            
                elif msg.text == RAKey + "scuadmin off":
                    if msg._from in self.wait["Owner"]:
                        if self.wait["RASDadmin"] == True:
                            self.wait["RASDadmin"] = False
                            cl.sendMessage(msg.to, "Hapus admin dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")
                            
                            
                elif msg.text == RAKey + "scstaff on":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        if self.wait["RASstaff"] == False:
                            self.wait["RASstaff"] = True
                            cl.sendMessage(msg.to, "kirim kontak untuk tambah staff")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")
                            
                elif msg.text == RAKey + "scstaff off":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        if self.wait["RASstaff"] == True:
                            self.wait["RASstaff"] = False
                            cl.sendMessage(msg.to, "Tambah staff dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")
                            
                elif msg.text == RAKey + "scustaff on":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        if self.wait["RASDstaff"] == False:
                            self.wait["RASDstaff"] = True
                            cl.sendMessage(msg.to, "kirim kontak untuk hapus staff")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")
                            
                elif msg.text == RAKey + "scustaff off":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        if self.wait["RASDstaff"] == True:
                            self.wait["RASDstaff"] = False
                            cl.sendMessage(msg.to, "Hapus staff dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")
                            
                elif msg.text == RAKey + "autoread on":
                    if msg._from in self.wait["Owner"]:
                        if self.wait["RAautoread"] == False:
                            self.wait["RAautoread"] = True
                            cl.sendMessage(msg.to, "Autoread diaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")
                            
                elif msg.text == RAKey + "autoread off":
                    if msg._from in self.wait["Owner"]:
                        if self.wait["RAautoread"] == True:
                            self.wait["RAautoread"] = False
                            cl.sendMessage(msg.to, "Autoread dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")
                            
                elif msg.text == self.resp + "cekmid on":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RAautoscan"] == False:
                            self.wait["RAautoscan"] = True
                            cl.sendMessage(msg.to, "Cek mid diaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")
                            
                elif msg.text == self.resp + "cekmid off":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RAautoscan"] == True:
                            self.wait["RAautoscan"] = False
                            cl.sendMessage(msg.to, "Cek mid dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")
                            
                elif msg.text == RAKey + "ngebot on":
                    if msg._from in self.wait["Owner"]:
                        if self.wait["RASbot"] == False:
                            self.wait["RASbot"] = True
                            cl.sendMessage(msg.to, "Tambah bot diaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")
                            
                elif msg.text == RAKey + "ngebot off":
                    if msg._from in self.wait["Owner"]:
                        if self.wait["RASbot"] == True:
                            self.wait["RASbot"] = False
                            cl.sendMessage(msg.to, "Tambah bot dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")            
                    
                elif msg.text == RAKey + "buangbot on":
                    if msg._from in self.wait["Owner"]:
                        if self.wait["RASDbot"] == False:
                            self.wait["RASDbot"] = True
                            cl.sendMessage(msg.to, "Buang bot diaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah on")
                            
                elif msg.text == RAKey + "buangbot off":
                    if msg._from in self.wait["Owner"]:
                        if self.wait["RASDbot"] == True:
                            self.wait["RASDbot"] = False
                            cl.sendMessage(msg.to, "Buang bot dinonaktifkan")
                        else:
                            cl.sendMessage(msg.to, "Sudah off")
                
                elif msg.text == RAKey + "lock invite":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.to in self.RAset["RAprotinvite"]:
                            cl.sendMessage(msg.to,"Block invite sudah diamankan")
                        else:
                            self.RAset["RAprotinvite"][msg.to] = True
                            f=codecs.open('RAset.json','w','utf-8')
                            json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"Block invite telah di tutup")
                            
                elif msg.text == RAKey + "unlock invite":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.to not in self.RAset["RAprotinvite"]:
                            cl.sendMessage(msg.to,"Block invite belum diamankan")
                        else:
                            del self.RAset["RAprotinvite"][msg.to]
                            f=codecs.open('RAset.json','w','utf-8')
                            json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"Block invite telah di buka")
                            
                elif msg.text == RAKey + "lock ourl":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.to in self.RAset["RAprotqr"]:
                            cl.sendMessage(msg.to,"Block ourl sudah diamankan")
                        else:
                            self.RAset["RAprotqr"][msg.to] = True
                            f=codecs.open('RAset.json','w','utf-8')
                            json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"Block ourl telah di tutup")
                            
                elif msg.text == RAKey + "unlock ourl":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.to not in self.RAset["RAprotqr"]:
                            cl.sendMessage(msg.to,"Block ourl belum diamankan")
                        else:
                            del self.RAset["RAprotqr"][msg.to]
                            f=codecs.open('RAset.json','w','utf-8')
                            json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"Block ourl telah di buka")
                            
                elif msg.text == RAKey + "lock cancel":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.to in self.RAset["RAprotcancel"]:
                            cl.sendMessage(msg.to,"Block cancel sudah diamankan")
                        else:
                            self.RAset["RAprotcancel"][msg.to] = True
                            f=codecs.open('RAset.json','w','utf-8')
                            json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"Block cancel telah di tutup")
                            
                elif msg.text == RAKey + "unlock cancel":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.to not in self.RAset["RAprotcancel"]:
                            cl.sendMessage(msg.to,"Block cancel belum diamankan")
                        else:
                            del self.RAset["RAprotcancel"][msg.to]
                            f=codecs.open('RAset.json','w','utf-8')
                            json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"Block cancel telah di buka")
                            
                elif msg.text == RAKey + "lock kick":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.to in self.RAset["RAprotkick"]:
                            cl.sendMessage(msg.to,"Block kick sudah diamankan")
                        else:
                            self.RAset["RAprotkick"][msg.to] = True
                            f=codecs.open('RAset.json','w','utf-8')
                            json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"Block kick telah di tutup")
                            
                elif msg.text == RAKey + "unlock kick":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.to not in self.RAset["RAprotkick"]:
                            cl.sendMessage(msg.to,"Block kick belum diamankan")
                        else:
                            del self.RAset["RAprotkick"][msg.to]
                            f=codecs.open('RAset.json','w','utf-8')
                            json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"Block kick telah di buka")
                            
                elif msg.text == RAKey + 'dw':
                    if msg._from in self.wait["Owner"]:
                    	try:self.RAset["warmode"] = {};f=codecs.open('RAset.json','w','utf-8');json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                    	except:pass
                    	cl.sendMessage(msg.to,"clean war DONE✅")

                elif msg.text == RAKey + "lock all":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.to in self.RAset["RAprotinvite"] or msg.to in self.RAset["RAprotqr"] or msg.to in self.RAset["RAprotcancel"] or msg.to in self.RAset["RAprotkick"]:
                            cl.sendMessage(msg.to,"All Protect on")
                        else:
                            self.RAset["RAprotinvite"][msg.to] = True
                            self.RAset["RAprotqr"][msg.to] = True
                            self.RAset["RAprotcancel"][msg.to] = True
                            self.RAset["RAprotkick"][msg.to] = True
                            G = cl.getGroup(msg.to).name
                            self.RAset["gname"][msg.to] = str(G)
                            f=codecs.open('RAset.json','w','utf-8')
                            json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"Akses telah di tutup")
                            
                elif msg.text == RAKey + "unlock all":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.to not in self.RAset["RAprotinvite"] or msg.to not in self.RAset["RAprotqr"] or msg.to not in self.RAset["RAprotcancel"] or msg.to not in self.RAset["RAprotkick"]:
                            cl.sendMessage(msg.to,"belum di amankan..")
                        else:
                            del self.RAset["RAprotinvite"][msg.to]
                            del self.RAset["RAprotqr"][msg.to]
                            del self.RAset["RAprotcancel"][msg.to]
                            del self.RAset["RAprotkick"][msg.to]
                            f=codecs.open('RAset.json','w','utf-8')
                            json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"group free..")            
                            
                elif msg.text == self.resp + "wellcome on":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.to in self.RAset["RAgreet"]:
                            cl.sendMessage(msg.to,"Pesan sambutan sudah aktif")
                        else:
                            self.RAset["RAgreet"][msg.to] = True
                            f=codecs.open('RAset.json','w','utf-8')
                            json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"Pesan sambutan diaktifkan")
                            
                elif msg.text == self.resp + "wellcome off":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.to not in self.RAset["RAgreet"]:
                            cl.sendMessage(msg.to,"Pesan sambutan tidak aktif")
                        else:
                            del self.RAset["RAgreet"][msg.to]
                            f=codecs.open('RAset.json','w','utf-8')
                            json.dump(self.RAset, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"Pesan sambutan dimatikan")            
                            
            #------------------- Protect Command Finish ------------------#
            
            
            #------------------- Main Command Start ------------------#
                        
                elif msg.text == self.resp + 'ourl':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.toType == 2:
                            x = cl.getGroup(msg.to)
                            if x.preventedJoinByTicket == True:
                                x.preventedJoinByTicket = False
                                cl.updateGroup(x)
                            gurl = cl.reissueGroupTicket(msg.to)
                            cl.sendMessage(msg.to,"line://ti/g/" + gurl)

                elif msg.text == self.resp + 'qr':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                    	x = cl.getGroup(msg.to)
                    	if x.preventedJoinByTicket == True:
                    	    x.preventedJoinByTicket = False
                    	    cl.updateGroup(x)
                    	    gurl = cl.reissueGroupTicket(msg.to)
                    	    for linkqr in self.wait["RABots"]:
                    	        try:cl.sendMessage(linkqr,"line://ti/g/" + gurl)
                    	        except:pass
                    	else:
                    	    gurl = cl.reissueGroupTicket(msg.to)
                    	    for linkqr in self.wait["RABots"]:
                    	        try:cl.sendMessage(linkqr,"line://ti/g/" + gurl)
                    	        except:pass


                elif msg.text == self.resp + 'curl':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.toType == 2:
                            X = cl.getGroup(msg.to)
                            X.preventedJoinByTicket = True
                            cl.updateGroup(X)
                            
                elif msg.text == self.resp + 'informasi':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        profile = cl.getProfile()
                        gid = cl.getGroupIdsJoined()
                        total = str(len(gid))
                        eltime = time.time() - mulai
                        
                        cin = " "+waktu(eltime)
                        cl.sendMessage(msg.to,"[Name]\n" + profile.displayName + "\n\n[Mid]\n" + profile.mid + "\n\n[Total Group]\n" + str(total) + "\n\n[Command Menu]\n" +self.resp+ " mamenu\n" +self.resp+ " msmenu\n" +self.resp+ " mpublic" "\n\n[Runtime]\n" + cin)
                        
                elif msg.text == self.resp + 'listgroup':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        gid = cl.getGroupIdsJoined()
                        h = "[List Groups]"
                        total = str(len(gid))
                        for i in gid:
                            if i is not None:
                                try:
                                    groups = cl.getGroup(i)
                                    if groups.members is not None:
                                        members = str(len(groups.members))
                                    else:
                                        members = "0"
                                    if groups.invitee is not None:
                                        pendings = str(len(groups.invitee))
                                    else:
                                        pendings = "0"
                                    h += "\n[" + groups.name + "]\n ->Members : " + members
                                except:
                                    break
                            else:
                                break
                        if gid is not None:
                            cl.sendMessage(msg.to,h + "\n|[Total Groups]| : " + str(total))
                        else:
                            cl.sendMessage(msg.to,"Tidak ada grup saat ini")
                        ginv = cl.getGroupIdsInvited()
                        j = "[List Groups Invited]"
                        totals = str(len(ginv))
                        for z in ginv:
                            if z is not None:
                                try:
                                    groups = cl.getGroup(z)
                                    if groups.members is not None:
                                        members = str(len(groups.members))
                                    else:
                                        members = "0"
                                    if groups.invitee is not None:
                                        pendings = str(len(groups.invitee))
                                    else:
                                        pendings = "0"
                                    j += "\n[" + groups.name + "]\n ->Members : " + members
                                except:
                                    break
                            else:
                                break
                        if ginv is not None:
                            cl.sendMessage(msg.to,j + "\n|[Total Groups Invited]| : " + str(totals))
                        else:
                            cl.sendMessage(msg.to,"Tidak ada grup tertunda saat ini")
                            
                elif msg.text == self.resp +'listidgroup':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        gid = cl.getGroupIdsJoined()
                        h = ""
                        for i in gid:
                            h += "[%s]:\n%s\n" % (cl.getGroup(i).name,i)
                        cl.sendMessage(msg.to,h)
                        
                elif self.resp +"cname " in msg.text:
                    if msg._from in self.wait["Owner"]:
                        string = msg.text.replace(self.resp + "cname ","")
                        profile_B = cl.getProfile()
                        profile_B.displayName = string
                        cl.updateProfile(profile_B)
                        cl.sendMessage(msg.to,"Berubah Menjadi " + string)
                            
                elif self.resp +"cbio " in msg.text:
                    if msg._from in self.wait["Owner"]:
                        string = msg.text.replace(self.resp + "cbio ","")
                        profile_B = cl.getProfile()
                        profile_B.statusMessage = string
                        cl.updateProfile(profile_B)
                        cl.sendMessage(msg.to,"Berubah Menjadi " + string)
                            
                elif msg.text == self.resp +"cfoto":
                    if msg._from in self.wait["Owner"]:
                        self.RAset["RAfoto"][self.mid] = True
                        cl.sendMessage(msg.to,"Kirim foto.....")
                        
                elif msg.text == self.resp +"cfotogroup":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        self.RAset["RAGfoto"][msg.to] = True
                        cl.sendMessage(msg.to,"Kirim foto.....")
                        
                elif self.resp +"masuk " in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        gid = msg.text.replace(self.resp + "masuk ","")
                        if gid == "":
                            cl.sendMessage(msg.to,"id grup salah")
                        else:
                            try:
                                x = cl.getGroup(gid)
                                if x.preventedJoinByTicket == True:
                                	x.preventedJoinByTicket = False
                                	cl.updateGroup(x)
                                	gurl = cl.reissueGroupTicket(gid)
                                	cl.sendMessage(msg.to,"Check u private chat")
                                	cl.sendMessage(msg._from,"line://ti/g/" + gurl)
                                else:
                                	gurl = cl.reissueGroupTicket(gid)
                                	cl.sendMessage(msg.to,"Check u private chat")
                                	cl.sendMessage(msg._from,"line://ti/g/" + gurl)
                            except Exception as e:
                                print(e)
                                
                elif self.resp +"bc " in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        text = msg.text.replace(self.resp + "bc ","")
                        gid = cl.getGroupIdsJoined()
                        if text == "":
                            cl.sendMessage(msg.to,"Tidak ada pesan")
                        else:
                            for i in gid:
                                cl.sendMessage(i,"??Broadcast\n\n" +text+ "\n")
                                
                elif self.resp + "kick" in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            if target in self.wait["Owner"] or target in self.wait["RAAdmin"] or target in self.wait["RAStaff"]:
                                pass
                            else:
                                try:
                                    cl.kickoutFromGroup(msg.to,[target])
                                except:
                                    cl.sendMessage(msg.to,"limit bos q")
                                    self.wait["limitkick"] = True
                                
                elif RAKey + "kick" in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            if target in self.wait["Owner"] or target in self.wait["RAAdmin"] or target in self.wait["RAStaff"]:
                                pass
                            else:
                                try:
                                    self.wait["RAblacklist"][target] = True
                                    f=codecs.open('RAwait.json','w','utf-8')
                                    json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    cl.kickoutFromGroup(msg.to,[target])
                                except:
                                    cl.sendMessage(msg.to,"limit bos q")
                                    self.wait["limitkick"] = True

                elif self.resp + "sun" in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            if target in self.wait["Owner"] or target in self.wait["RAAdmin"] or target in self.wait["RAStaff"]:
                                pass
                            else:
                                try:
                                    self.wait["RAblacklist"][target] = True
                                    f=codecs.open('RAwait.json','w','utf-8')
                                    json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    cl.kickoutFromGroup(msg.to,[target])
                                except:
                                    cl.sendMessage(msg.to,"limit bos q")
                                    self.wait["limitkick"] = True

                elif RAKey + "bl" in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            if target in self.wait["Owner"] or target in self.wait["RAAdmin"] or target in self.wait["RAStaff"]:
                                pass
                            else:
                                try:
                                    self.wait["RAblacklist"][target] = True
                                    f=codecs.open('RAwait.json','w','utf-8')
                                    json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    cl.sendMessage(msg.to,"Akun terblacklist")
                                except:
                                    cl.sendMessage(msg.to,"Sudah terblacklist")
                                    
                elif RAKey + "ubl" in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:
                            if target in self.wait["Owner"] or target in self.wait["RAAdmin"] or target in self.wait["RAStaff"]:
                                pass
                            else:
                                try:
                                    del self.wait["RAblacklist"][target]
                                    f=codecs.open('RAwait.json','w','utf-8')
                                    json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    cl.sendMessage(msg.to,"Akun bersih blacklist")
                                except:
                                    cl.sendMessage(msg.to,"Tidak terblacklist")
                                
                elif msg.text == RAKey +"mspam":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        if self.wait["RAmessage"] is not None:
                            cl.sendMessage(msg.to,"Message \"" + str(self.wait['RAmessage']) + "\"")
                        else:
                            cl.sendMessage(msg.to,"Tidak ada pesan yang diatur")
                    
                elif msg.text == RAKey +"cspam ":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        text = msg.text.replace(RAKey +"cspam ","")
                        try:
                            self.wait["RAmessage"] = text
                            cl.sendMessage(msg.to,"Berubah menjadi \"" + text + "\"")
                        except:
                            cl.sendMessage(msg.to,"Gagal mengganti pesan")
                            
                elif RAKey + "owadd" in msg.text:
                    if msg._from in Creator:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:    
                            if target in self.wait["Owner"]:
                                cl.sendMessage(msg.to,"Sudah terdaftar...")
                            else:
                                self.wait["Owner"][target] = True
                                f=codecs.open('RAwait.json','w','utf-8')
                                json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                            cl.sendMessage(msg.to,"Terdaftar menjadi Owner")
                                    
                elif RAKey + "owdell" in msg.text:
                    if msg._from in Creator:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:    
                            if target not in self.wait["Owner"]:
                                cl.sendMessage(msg.to,"Sudah dihapus...")
                            else:
                                try:
                                    del self.wait["Owner"][target]
                                    f=codecs.open('RAwait.json','w','utf-8')
                                    json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    cl.sendMessage(msg.to,"Dihapus menjadi Owner")
                                except Exception as e:
                                    cl.sendMessage(msg.to,"Erorr...")

                elif RAKey + "adadd" in msg.text:
                    if msg._from in self.wait["Owner"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:    
                            if target in self.wait["RAAdmin"]:
                                cl.sendMessage(msg.to,"Sudah terdaftar...")
                            else:
                                try:
                                    self.wait["RAAdmin"][target] = True
                                    f=codecs.open('RAwait.json','w','utf-8')
                                    json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    cl.sendMessage(msg.to,"Terdaftar menjadi admin")
                                except Exception as e:
                                    cl.sendMessage(msg.to,"Erorr....")
                                    
                elif RAKey + "addell" in msg.text:
                    if msg._from in self.wait["Owner"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:    
                            if target not in self.wait["RAAdmin"]:
                                cl.sendMessage(msg.to,"Sudah dihapus...")
                            else:
                                try:
                                    del self.wait["RAAdmin"][target]
                                    f=codecs.open('RAwait.json','w','utf-8')
                                    json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    cl.sendMessage(msg.to,"Dihapus menjadi admin")
                                except Exception as e:
                                    cl.sendMessage(msg.to,"Erorr...")
                                    
                elif RAKey + "stadd" in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:    
                            if target in self.wait["RAStaff"]:
                                cl.sendMessage(msg.to,"Sudah terdaftar...")
                                pass
                            else:
                                try:
                                    self.wait["RAStaff"][target] = True
                                    f=codecs.open('RAwait.json','w','utf-8')
                                    json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    cl.sendMessage(msg.to,"Terdaftar menjadi staff")
                                except Exception as e:
                                    cl.sendMessage(msg.to,"Erorr.....")
                                    
                elif RAKey + "stdell" in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:    
                            if target not in self.wait["RAStaff"]:
                                cl.sendMessage(msg.to,"Sudah dihapus...")
                                pass
                            else:
                                try:
                                    del self.wait["RAStaff"][target]
                                    f=codecs.open('RAwait.json','w','utf-8')
                                    json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    cl.sendMessage(msg.to,"Dihapus menjadi staff")
                                except Exception as e:
                                    cl.sendMessage(msg.to,"Erorr...")
                                    
                elif RAKey + "tbot" in msg.text:
                    if msg._from in self.wait["Owner"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:    
                            if target in self.wait["RABots"]:
                                cl.sendMessage(msg.to,"Sudah terdaftar...")
                                pass
                            else:
                                try:
                                    self.wait["RABots"][target] = True
                                    f=codecs.open('RAwait.json','w','utf-8')
                                    json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                except:pass
                        cl.sendMessage(msg.to,"berhasil bos..")
                elif RAKey + "cuekinbot" in msg.text:
                    if msg._from in self.wait["Owner"]:
                        key = eval(msg.contentMetadata["MENTION"])
                        key["MENTIONEES"][0]["M"]
                        targets = []
                        for x in key["MENTIONEES"]:
                            targets.append(x["M"])
                        for target in targets:    
                            if target not in self.wait["RABots"]:
                                cl.sendMessage(msg.to,"Sudah dihapus...")
                                pass
                            else:
                                try:
                                    del self.wait["RABots"][target]
                                    f=codecs.open('RAwait.json','w','utf-8')
                                    json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                    cl.sendMessage(msg.to,"Dihapus dari listbot")
                                except Exception as e:
                                    cl.sendMessage(msg.to,"Erorr...")                    
                                    
                elif msg.text == self.resp +"listbl":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RAblacklist"] == {}:
                            cl.sendMessage(msg.to,"Tidak ada akun terblacklist")
                        else:
                            mc = "[User "
                            num=1
                            ragets = cl.getContacts(self.wait["RAblacklist"])
                            for mi_d in ragets:
                                mc+="\n%i. %s" % (num, mi_d.displayName)
                                num=(num+1)
                            mc+="\n\n Total %i Blacklist] " % len(ragets)     
                            cl.sendMessage(msg.to, mc)
                            
                elif msg.text == self.resp +"clearbl":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RAblacklist"] == {}:
                            cl.sendMessage(msg.to,"Tidak ada akun terblacklist")
                        else:
                            mc = "[User "
                            num=1
                            ragets = cl.getContacts(self.wait["RAblacklist"])
                            for mi_d in ragets:
                            	del self.wait["RAblacklist"][ragets]
                            	f=codecs.open('RAwait.json','w','utf-8')
                            	json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                            	mc+="\n%i. %s" % (num, mi_d.displayName)
                            	num=(num+1)
                            mc+="\n\n Total %i Blacklist] " % len(ragets)     
                            cl.sendMessage(msg.to, mc)

                elif msg.text == self.resp +"listteam":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"] or msg._from in Creator:
                        ma = ""
                        mb = ""
                        mc = ""
                        a = 0
                        b = 0
                        c = 0
                        for m_id in self.wait["Owner"]:
                            a = a + 1
                            end = '\n'
                            ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                        for m_id in self.wait["RAAdmin"]:
                            b = b + 1
                            end = '\n'
                            mb += str(b) + ". " +cl.getContact(m_id).displayName + "\n"
                        for m_id in self.wait["RAStaff"]:
                            c = c + 1
                            end = '\n'
                            mc += str(c) + ". " +cl.getContact(m_id).displayName + "\n"
                        cl.sendMessage(msg.to,"     Daftar pengguna bot GALAXY\n\nOwner:\n"+ma+"\nAdmin:\n"+mb+"\nStaff:\n"+mc+"\n\nada %s orang\n\nSupport by\nT̘̟̼̉̈́͐͋͌̊e̮̟͈̣̖̰̩̹͈̾ͨ̑͑a̘̫͈̭͌͛͌̇̇̍m̘͈̺̪͓ͩ͂̾ͪ̀̋b͎̣̫͈̥͒͌̃͑̔̾ͅo̜̓̇ͫ̉͊ͨt̘̟̼̉̈́͐͋͌̊a̘̫͈͌͛͌̇̇̍m̘͈̺̪͓̺ͩ͂̾ͪ̀̋a̘̫͈͌͛͌̇̇̍t̘̟̼̉̈́͐͋͌̊i̞̟̫̺ͭ̒ͭͣr̼̯̤̗̲̞̥̈ͭ̃ͨ̆a̘̫͈̭͌͛͌̇̇̍n͉̠̙͉̗̺̋̔ͧ̊" %(str(len(self.wait["Owner"])+len(self.wait["RAStaff"])+len(self.wait["RAAdmin"]))))
                        
                elif msg.text == self.resp +"listbot":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["RABots"] == {}:
                            cl.sendMessage(msg.to,"List bot kosong")
                        else:
                            mc = "[User "
                            num=1
                            ragets = cl.getContacts(self.wait["RABots"])
                            for mi_d in ragets:
                                mc+="\n%i. %s" % (num, mi_d.displayName)
                                num=(num+1)
                            mc+="\n\n Total %i botline] " % len(ragets)     
                            cl.sendMessage(msg.to, mc)

                elif msg.text == self.resp +"listcust":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if self.wait["GLcust"] == {}:
                            cl.sendMessage(msg.to,"List customer kosong")
                        else:
                            mc = "[User "
                            num=1
                            ragets = cl.getContacts(self.wait["GLcust"])
                            for mi_d in ragets:
                                mc+="\n%i. %s" % (num, mi_d.displayName)
                                num=(num+1)
                            mc+="\n\n Total %i CUSTOMER line] " % len(ragets)     
                            cl.sendMessage(msg.to, mc)
                            
                elif msg.text == self.resp +"cancel":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.toType == 2:
                            group = cl.getGroup(msg.to)
                            gMembMids = [contact.mid for contact in group.invitee]
                            for _mid in gMembMids:
                                cl.cancelGroupInvitation(msg.to,[_mid])
                            else:
                                cl.sendMessage(msg.to,"Selesai cancel member")
                                
                elif msg.text == self.resp +"listprotect":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        ma = ""
                        a = 0
                        mb = ""
                        b = 0
                        mc = ""
                        c = 0
                        md = ""
                        d = 0
                        gid = self.RAset["RAprotinvite"]
                        for group in gid:
                            G = cl.getGroup(group)
                            a = a + 1
                            end = "\n"
                            ma += str(a) + ". " +G.name+ "\n"
                        gid = self.RAset["RAprotqr"]
                        for group in gid:
                            G = cl.getGroup(group)
                            b = b + 1
                            end = "\n"
                            mb += str(b) + ". " +G.name+ "\n"
                        gid = self.RAset["RAprotcancel"]
                        for group in gid:
                            G = cl.getGroup(group)
                            c = c + 1
                            end = "\n"
                            mc += str(c) + ". " +G.name+ "\n"
                        gid = self.RAset["RAprotkick"]
                        for group in gid:
                            G = cl.getGroup(group)
                            d = d + 1
                            end = "\n"
                            md += str(d) + ". " +G.name+ "\n"
                        cl.sendMessage(msg.to,"  Listprotect\n\nProtect Invite:\n"+ma+"\nProtect Ourl:\n"+mb+"\nProtect Cancel:\n"+mc+"\nProtect Kick:\n"+md)    
                                
                elif msg.text == self.resp +"sprespon":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        get_profile_time_start = time.time()
                        get_profile = cl.getProfile()
                        get_profile_time = time.time() - get_profile_time_start
                        get_group_time_start = time.time()
                        get_group = cl.getGroupIdsJoined()
                        get_group_time = time.time() - get_group_time_start
                        get_contact_time_start = time.time()
                        get_contact = cl.getContact(self.mid)
                        get_contact_time = time.time() - get_contact_time_start
                        cl.sendMessage(msg.to, "ãspeed responã\n + Get Profile\n   %.10f\n + Get Contact\n   %.10f\n + Get Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))
                    
                elif RAKey +"masukin" in msg.text:
                    if msg._from in self.wait["Owner"]:
                        gs = cl.getGroup(msg.to)
                        targets = []
                        for x in gs.members:
                            targets.append(x.mid)
                        for a in self.wait["RABots"]:
                            if a in targets:
                                try:
                                    targets.remove(a)
                                except:
                                    pass
                        cl.sendMessage(msg.to,"Sudah masuk kedalam list")
                        for target in targets:
                            if target not in self.wait["Owner"]:
                                if target not in self.wait["RAAdmin"]:
                                    if target not in self.wait["RAStaff"]:
                                        try:
                                            self.wait["RABots"][target] = True
                                            f=codecs.open('RAwait.json','w','utf-8')
                                            json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
                                        except:
                                            pass    
                        cl.sendMessage(msg.to,"Berhasil..")

                elif RAKey +"cust" in msg.text:
                    if msg._from in self.wait["Owner"]:
                        gs = cl.getGroup(msg.to)
                        targets = []
                        for x in gs.members:
                            targets.append(x.mid)
                        for a in self.wait["GLcust"]:
                            if a in targets:
                                try:
                                    targets.remove(a)
                                except:
                                    pass
#                        cl.sendMessage(msg.to,"Sudah masuk kedalam list")
                        for target in targets:
                            if target not in self.wait["Owner"]:
                                if target not in self.wait["RAAdmin"]:
                                    if target not in self.wait["RAStaff"]:
                                        try:
                                            self.wait["GLcust"][target] = True
                                            f=codecs.open('RAwait.json','w','utf-8')
                                            json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)
#                                            cl.sendMessage(msg.to,"Berhasil..")
                                        except:
                                            pass    

                elif msg.text == self.resp +"run10":
                    if msg._from in self.wait["Owner"]:
                        if msg.toType == 2:
                            try:os.system('screen -S 10as -X quit');os.system('rm -rf clone/10as');time.sleep(2);cl.sendMessage(msg.to, "screen is closings....")
                            except:pass
                            try:os.system('screen -dmS 10as');os.system('screen -r 10as -X stuff "python3.5 10bot.py\n"');cl.sendMessage(msg.to,"6~10 Asbot Aktived\nTunggu beberapa saat..")
                            except:pass
                            try:os.system('screen -S as10 -X quit');os.system('rm -rf clone/as10');time.sleep(2);cl.sendMessage(msg.to, "screen is closings....")
                            except:pass

                elif msg.text == self.resp +"run5":
                    if msg._from in self.wait["Owner"]:
                        if msg.toType == 2:
                            try:os.system('screen -S 5as -X quit');os.system('rm -rf clone/5as');time.sleep(2);cl.sendMessage(msg.to, "screen is closings....")
                            except:pass
                            try:os.system('screen -dmS 5as');os.system('screen -r 5as -X stuff "python3.5 5bot.py\n"');cl.sendMessage(msg.to,"1~5 Asbot Aktived\nTunggu beberapa saat..")
                            except:pass
                            try:os.system('screen -S as5 -X quit');os.system('rm -rf clone/as5');time.sleep(2);cl.sendMessage(msg.to, "screen is closings....")
                            except:pass

                elif msg.text == self.resp +"ganti10":
                    if msg._from in self.wait["Owner"]:
                        if msg.toType == 2:
                            try:os.system('screen -S as10 -X quit');os.system('rm -rf clone/as10');time.sleep(2);cl.sendMessage(msg.to, "screen is closings....")
                            except:pass
                            try:os.system('screen -dmS as10');os.system('screen -r as10 -X stuff "python3.5 20bot.py\n"');cl.sendMessage(msg.to,"Pergantian kulit\nTunggu beberapa saat..")
                            except:pass
                            try:os.system('screen -S 10as -X quit');os.system('rm -rf clone/10as');time.sleep(2);cl.sendMessage(msg.to, "ganti baju dulu....")
                            except:pass

                elif msg.text == self.resp +"ganti5":
                    if msg._from in self.wait["Owner"]:
                        if msg.toType == 2:
                            try:os.system('screen -S as5 -X quit');os.system('rm -rf clone/as5');time.sleep(2);cl.sendMessage(msg.to, "screen is closings....")
                            except:pass
                            try:os.system('screen -dmS as5');os.system('screen -r as5 -X stuff "python3.5 15bot.py\n"');cl.sendMessage(msg.to,"Pergantian Kulit\nTunggu beberapa saat..")
                            except:pass
                            try:os.system('screen -S 5as -X quit');os.system('rm -rf clone/5as');time.sleep(2);cl.sendMessage(msg.to, "ganti baju dulu....")
                            except:pass

                elif msg.text == self.resp +"lg10":
                    if msg._from in self.wait["Owner"]:
                        if msg.toType == 2:
                            cl.sendMessage(msg.to, "Done...")
                            try:os.system('screen -S as10 -X quit');os.system('rm -rf clone/as10');time.sleep(2);cl.sendMessage(msg.to, "screen is closings....")
                            except:pass
                            try:os.system('screen -S 10as -X quit');os.system('rm -rf clone/10as');time.sleep(2);cl.sendMessage(msg.to, "6~10bot wafat")
                            except:pass

                elif msg.text == self.resp +"invitebos":
                    if msg._from in self.wait["Owner"]:
                    	for bos in self.wait["Owner"]:
                    		try:
                    			cl.findAndAddContactsByMid(bos)
                    		except:pass
                    		cl.inviteIntoGroup(msg.to,self.wait["Owner"])
                    		
                elif msg.text == self.resp +"invite bot":
                    if msg._from in self.wait["Owner"]:
                    	for bot in self.wait["RABots"]:
                    		try:
                    			cl.findAndAddContactsByMid(bot)
                    		except:pass
                    	cl.inviteIntoGroup(msg.to,self.wait["RABots"])
        #---------------------- Multy Command ------------------------#
                
                elif msg.text == RAKey +'r':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        profile = cl.getProfile()
                        text = profile.displayName + ""
                        cl.sendMessage(msg.to, text)

                elif msg.text == RAKey + 'sp':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        start = time.time()
                        iyo = cl.getContact(self.mid)
                        elapsed_time = time.time() - start
                        cl.sendMessage(msg.to, "「 Test Speedᴾᴿᴼ™̶」\n{} detik".format(str(elapsed_time)))

                elif RAKey +"cname " in msg.text:
                    if msg._from in self.wait["Owner"]:
                        string = msg.text.replace(RAKey + "cname ","")
                        profile_B = cl.getProfile()
                        profile_B.displayName = string
                        cl.updateProfile(profile_B)
                        cl.sendMessage(msg.to,"Berubah Menjadi " + string)

                elif RAKey +"cnamegrup " in msg.text:
                    if msg._from in self.wait["Owner"]:
                        string = msg.text.replace(RAKey + "cnamegrup ","")
                        X = cl.getGroup(msg.to)
                        X.name = string
                        cl.updateGroup(X)
                        cl.sendMessage(msg.to,"Nama grup diganti jadi " + string)
                            
                elif RAKey +"cbio " in msg.text:
                    if msg._from in self.wait["Owner"]:
                        string = msg.text.replace(RAKey + "cbio ","")
                        profile_B = cl.getProfile()
                        profile_B.statusMessage = string
                        cl.updateProfile(profile_B)
                        cl.sendMessage(msg.to,"Berubah Menjadi " + string)
                            
                elif msg.text == RAKey +"cfoto":
                    if msg._from in self.wait["Owner"]:
                        self.RAset["RAfoto"][msg.to] = True
                        cl.sendMessage(msg.to,"Kirim foto.....")
                        
                elif msg.text == RAKey +'cleanblacklist':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        group = cl.getGroup(msg.to)
                        gMembMids = [contact.mid for contact in group.members]
                        matched_list = []
                        if matched_list != []:
                            cl.sendMessage(msg.to,"Blacklisted contact noticed...")
                            cl.sendMessage(msg.to,"Begin Kicking contact")
                        for tag in self.wait["RAblacklist"]:
                            matched_list+=filter(lambda str: str == tag, gMembMids)
                        if matched_list == []:
                            cl.sendMessage(msg.to,"It looks empty here.")
                            return
                        for jj in matched_list:
                            cl.kickoutFromGroup(msg.to,[jj])
                
                elif msg.text == RAKey +'byeall':
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if msg.toType == 2:
                            x = cl.getGroup(msg.to)
                            cl.leaveGroup(msg.to)
                            
                elif msg.text == RAKey +'leaveall':
                    if msg._from in self.wait["Owner"]:
                        gid = cl.getGroupIdsJoined()
                        for i in gid:
                            cl.sendMessage(i,"Tugas Sudah Selesai.... \n\n\nSilahkan Hubungi OWner kami...")
                            cl.leaveGroup(i)

                elif RAKey + "kuy" in msg.text:
                    if msg._from in self.wait["Owner"]:
                        cl.sendMessage(msg.to,"!galaxy")

                elif RAKey + "galaxy" in msg.text:
                    #if self.wait["galaxy"] == True:
                        self.wait["RABots"][self.mid] = True
                        self.wait["RABots"][msg._from] = True
                        cl.findAndAddContactsByMid(msg._from)
                        f=codecs.open('RAwait.json','w','utf-8')
                        json.dump(self.wait, f, sort_keys=True, indent=4,ensure_ascii=False)


                elif RAKey + "gas" in msg.text:
                    if msg._from in self.wait["Owner"]:
                        gs = cl.getGroup(msg.to)
                        targets = []
                        for x in gs.members:
                            targets.append(x.mid)
                        for a in self.wait["RABots"]:
                            if a in targets:
                                try:
                                    targets.remove(a)
                                except:
                                    pass
                        for b in self.wait["RAAdmin"]:
                            if b in targets:
                                try:
                                    targets.remove(b)
                                except:
                                    pass
                        for c in self.wait["Owner"]:
                            if c in targets:
                                try:
                                    targets.remove(c)
                                except:
                                    pass
                        for d in self.wait["RAStaff"]:
                            if d in targets:
                                try:
                                    targets.remove(d)
                                except:
                                    pass
                        #cl.sendMessage(msg.to,"Byebye")
                        for target in targets:
                            try:
                                cl.kickoutFromGroup(msg.to,[target])
                            except:
                                cl.sendMessage(msg.to, "limit bos q")
                                self.wait["limitkick"] = True
                elif self.resp + "gas" in msg.text:
                    if msg._from in self.wait["Owner"]:
                        gs = cl.getGroup(msg.to)
                        targets = []
                        for x in gs.members:
                            targets.append(x.mid)
                        for a in self.wait["RABots"]:
                            if a in targets:
                                try:
                                    targets.remove(a)
                                except:
                                    pass
                        for b in self.wait["RAAdmin"]:
                            if b in targets:
                                try:
                                    targets.remove(b)
                                except:
                                    pass
                        for c in self.wait["Owner"]:
                            if c in targets:
                                try:
                                    targets.remove(c)
                                except:
                                    pass
                        for d in self.wait["RAStaff"]:
                            if d in targets:
                                try:
                                    targets.remove(d)
                                except:
                                    pass
                        #cl.sendMessage(msg.to,"Byebye")
                        for target in targets:
                            try:
                                cl.kickoutFromGroup(msg.to,[target])
                            except:
                                cl.sendMessage(msg.to, "limit bos q")
                                self.wait["limitkick"] = True
                elif msg.text == RAKey +'friend':
                    if msg._from in self.wait["Owner"]:
                        ragets = cl.getAllContactIds()
                        racekcontact = cl.getContacts(ragets)
                        num=1
                        msgs=""
                        for ids in racekcontact:
                            msgs+="\n%i. %s" % (num, ids.displayName)
                            num=(num+1)
                        msgs+="\n\nãTotal %i Friend'sã " % len(racekcontact)
                        cl.sendMessage(msg.to, msgs)
                        
                elif msg.text == RAKey +"spam ":
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        spm = msg.text.replace(self.resp + "spam ","")
                        sspm = spm.split()
                        midd = sspm[0]
                        jumlah = int(sspm[1])
                        if jumlah <= 100:
                            for var in range(0,jumlah):
                                if (self.wait["RAmessage"] in [" "," ","\n",None]):
                                    pass
                                else:
                                    cl.findAndAddContactsByMid(midd)
                                    cl.sendMessage(midd,str(self.wait["RAmessage"]))
                                    
                elif msg.text == RAKey + 'restart':
                    if msg._from in self.wait["Owner"]:
                        cl.sendMessage(msg.to,"Tunggu Sebentar..")
                        python3 = sys.executable
                        os.execl(python3, python3, *sys.argv)
                
                elif msg.text == RAKey + 'removechat':
                    if msg._from in self.wait["Owner"]:
                        try:
                            cl.removeAllMessages(op.param2)
                            cl.sendMessage(msg.to,"Chat Bersih....")
                        except:
                            pass
                                    
                elif RAKey +'keluar ' in msg.text:
                    if msg._from in self.wait["Owner"]:
                        ng = msg.text.replace(RAKey + 'keluar ','')
                        gid = cl.getGroupIdsJoined()
                        for i in gid:
                            h = cl.getGroup(i).name
                            if h == ng:
                            	cl.sendMessage(i, "Tugas selesai.... \nBos menyuruh kami Keluar dari sini...\nBye...")
                            	cl.leaveGroup(i)
                            	cl.sendMessage(msg.to, "Done")
                                #cl.leaveGroup(i)
                    
                        
                elif msg.text == RAKey + "spin":
                    if msg._from in self.wait["Owner"]:
                        try:
                        	text = msg.text.lower().replace(RAKey + "spin","")
                        	split = text.split(" ")
                        	namaGrup = split[1]
                        	jmlh = 0
                        	try:
                        	    jmlh = int(split[2])
                        	except:
                        	    cl.sendMessage(msg.to,"Group Name Can't use spaces")
                        	midd = split[3]
                        	cl.findAndAddContactsByMid(midd)
                        	while jmlh > 0:
                        	    #time.sleep(50)
                        	    group = cl.createGroup(namaGrup,[midd])
                        	    group_id = group.id
                        	    jmlh = jmlh - 1
                        	    cl.leaveGroup(group_id)
                        	cl.sendMessage(msg.to,"Success SpamGroup!")
                        except Exception as e:
                        	cl.log("ERROR SPAM INV: "+str(e))
        #---------------------- Mix Command ------------------------#
        
                elif self.resp + "limit " in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        strnum = msg.text.replace(self.resp + "limit ","")
                        num =  int(strnum)
                        self.wait["RAlimit"] = num
                        cl.sendMessage(msg.to,"Total Diubah Menjadi " +strnum)
                        
                elif self.resp + "sc " in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if 'MENTION' in msg.contentMetadata.keys()!=None:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            jmlh = int(self.wait["RAlimit"])
                            if jmlh <= 1000:
                                for x in range(jmlh):
                                    try:
                                        msg.contentType = 13
                                        msg.contentMetadata = {'mid': key1}
                                        cl.sendMessage1(msg)
                                    except Exception as e:
                                        cl.sendMessage(msg.to,str(e))
                            else:
                                cl.sendMessage(msg.to,"Jumlah melebihi 1000")             
                elif self.resp + "panggil " in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"]:
                        if 'MENTION' in msg.contentMetadata.keys()!=None:
                            key = eval(msg.contentMetadata["MENTION"])
                            key1 = key["MENTIONEES"][0]["M"]
                            zx = ""
                            zxc = " "
                            zx2 = []
                            pesan2 = "@a"" "
                            xlen = str(len(zxc))
                            xlen2 = str(len(zxc)+len(pesan2)-1)
                            zx = {'S':xlen, 'E':xlen2, 'M':key1}
                            zx2.append(zx)
                            zxc += pesan2
                            msg.contentType = 0
                            msg.text = zxc
                            lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                            msg.contentMetadata = lol
                            jmlh = int(self.wait["RAlimit"])
                            if jmlh <= 1000:
                                for x in range(jmlh):
                                    try:
                                        cl.sendMessage1(msg)
                                    except Exception as e:
                                        cl.sendMessage(msg.to,str(e))
                            else:            
                                cl.sendMessage(msg.to,"Jumlah melebihi 1000")            
                                    
                            
                elif self.resp + "cek" in msg.text:
                    key = eval(msg.contentMetadata["MENTION"])
                    key1 = key["MENTIONEES"][0]["M"]
                    contact = cl.getContact(key1)
                    try:
                        path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                        cl.sendImageWithURL(msg.to,path)
                        cl.sendMessage(msg.to,"[Name]\n" + contact.displayName + "\n\n[Mid]\n" + contact.mid + "\n\n[Status message]\n" + contact.statusMessage)
                    except:
                        path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                        cl.sendImageWithURL(msg.to,path)
                        cl.sendMessage(msg.to,"[Name]\n" + contact.displayName + "\n\n[Mid]\n" + contact.mid + "\n\n[Status message]\n" + contact.statusMessage)
                        
                elif msg.text == self.resp +"gid":
                    cl.sendMessage(msg.to,msg.to)
                    
                elif msg.text == self.resp +"yid":
                    cl.sendMessage(msg.to,msg._from)
                    
                elif msg.text == self.resp +"cctv on":
                    self.RAset['RAreadPoint'][msg.to] = msg.id
                    self.RAset['RAreadMember'][msg.to] = {}
                    cl.sendMessage(msg.to, "CCTV di pasang...")
                    
                elif msg.text == self.resp +"cctv off":
                    del self.RAset['RAreadPoint'][msg.to]
                    del self.RAset['RAreadMember'][msg.to]
                    cl.sendMessage(msg.to, "CCTV dinonaktifkan")
                    
                elif msg.text == self.resp +"cyduk":
                    if msg.to in self.RAset['RAreadPoint']:
                        if self.RAset['RAreadMember'][msg.to] != {}:
                            aa = []
                            for x in self.RAset['RAreadMember'][msg.to]:
                                aa.append(x)
                            try:
                                arrData = ""
                                textx = "     [ Terpantau ada {} orang Ngintip ]    \n1. ".format(str(len(aa))) 
                                arr = []
                                no = 1
                                b = 1
                                for i in aa:
                                    b = b + 1
                                    end = "\n"
                                    mention = "@x\n"
                                    slen = str(len(textx))
                                    elen = str(len(textx) + len(mention) - 1)
                                    arrData = {'S':slen, 'E':elen, 'M':i}
                                    arr.append(arrData)
                                    textx += mention
                                    if no < len(aa):
                                        no += 1
                                        textx += str(b) + ". "
                                    else:
                                        try:
                                            no = "[ {} ]".format(str(cl.getGroup(msg.to).name))
                                        except:
                                            no = "  "
                                msg.to = msg.to
                                msg.text = textx
                                msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                msg.contentType = 0
                                cl.sendMessage1(msg)
                            except:
                                pass
                            try:
                                del self.RAset['RAreadPoint'][msg.to]
                                del self.RAset['RAreadMember'][msg.to]
                            except:
                                pass
                            self.RAset['RAreadPoint'][msg.to] = msg.id
                            self.RAset['RAreadMember'][msg.to] = {}
                        else:
                            cl.sendMessage(msg.to, "Belum ada pelaku...")
                    else:
                        cl.sendMessage(msg.to, "Pasang dulu CCTV nya...")
        
                elif msg.text == self.resp +"tagall":
                    group = cl.getGroup(msg.to)
                    k = len(group.members)//20
                    for j in range(k+1):
                        aa = []
                        for x in group.members[j*20 : (j+1)*20]:
                            aa.append(x.mid)
                        try:
                            arrData = ""
                            textx = "     [ Mention {} Members ]    \n1. ".format(str(len(aa)))
                            arr = []
                            no = 1
                            b = 1
                            for i in aa:
                                b = b + 1
                                end = "\n"
                                mention = "@x\n"
                                slen = str(len(textx))
                                elen = str(len(textx) + len(mention) - 1)
                                arrData = {'S':slen, 'E':elen, 'M':i}
                                arr.append(arrData)
                                textx += mention
                                if no < len(aa):
                                    no += 1
                                    textx += str(b) + ". "
                                else:
                                    try:
                                        no = "[ {} ]".format(str(cl.getGroup(msg.to).name))

                                    except:
                                        no = " "
                            msg.to = msg.to
                            msg.text = textx
                            msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                            msg.contentType = 0
                            cl.sendMessage1(msg)
                        except Exception as e:
                            cl.sendMessage(msg.to,str(e))
                            
                elif self.resp + 'yt-video ' in msg.text:
                    try:
                        textToSearch = (msg.text).replace(self.resp + 'yt-video ', "").strip()
                        query = urllib.parse.quote(textToSearch)
                        url = "https://www.youtube.com/results?search_query=" + query
                        response = urllib.request.urlopen(url)
                        html = response.read()
                        soup = BeautifulSoup(html, "html.parser")
                        results = soup.find(attrs={'class':'yt-uix-tile-link'})
                        dl = 'https://www.youtube.com' + results['href']
                        start = timeit.timeit()
                        vid = pafy.new(dl)
                        stream = vid.streams
                        for s in stream:
                            vin = s.url
                            hasil = vid.title
                            hasil += '\n\nPenulis : ' +str(vid.author)
                            hasil += '\nDurasi   : ' +str(vid.duration)+ ' (' +s.quality+ ') '
                            hasil += '\nRating   : ' +str(vid.rating)
                            hasil += '\nDitonton    : ' +str(vid.viewcount)+ 'x '
                            hasil += '\nDiterbitkan : ' +vid.published
                            hasil += '\n\nTime taken : %s' % (start)
                            hasil += '\n\n Tunggu encoding selesai...'
                        cl.sendVideoWithURL(msg.to,vin)
                        cl.sendMessage(msg.to,hasil)
                    except:
                        cl.sendMessage(msg.to,"Informasi video gagal di cari")
                        
                elif self.resp + 'yt-mp3 ' in msg.text:
                    try:
                        textToSearch = (msg.text).replace(self.resp + 'yt-mp3 ', "").strip()
                        query = urllib.parse.quote(textToSearch)
                        url = "https://www.youtube.com/results?search_query=" + query
                        response = urllib.request.urlopen(url)
                        html = response.read()
                        soup = BeautifulSoup(html, "html.parser")
                        results = soup.find(attrs={'class':'yt-uix-tile-link'})
                        dl = 'https://www.youtube.com' + results['href']
                        start = timeit.timeit()
                        vid = pafy.new(dl)
                        stream = vid.audiostreams
                        for s in stream:
                            vin = s.url
                            path = vid.bigthumbhd
                            hasil = vid.title
                            hasil += '\n\nPenulis : ' +str(vid.author)
                            hasil += '\nDurasi   : ' +str(vid.duration)+ ' (' +s.quality+ ') '
                            hasil += '\nRating   : ' +str(vid.rating)
                            hasil += '\nDitonton    : ' +str(vid.viewcount)+ 'x '
                            hasil += '\nDiterbitkan : ' +vid.published
                            hasil += '\n\nTime taken : %s' % (start)
                            hasil += '\n\n Tunggu encoding selesai...'
                        cl.sendImageWithURL(msg.to, str(path))    
                        cl.sendAudioWithURL(msg.to,vin)
                        cl.sendMessage(msg.to,hasil)
                    except:
                        cl.sendMessage(msg.to,"Informasi Audio gagal di cari")
                        
                elif self.resp + 'film ' in msg.text:
                    proses = msg.text.replace(self.resp +'film ','')
                    prosess = proses.split()
                    title = prosess[0]
                    tahun = prosess[1]
                    r = requests.get('http://www.omdbapi.com/?t='+title+'&y='+tahun+'&plot=full&apikey=4bdd1d70')
                    start = timeit.timeit()
                    data=r.text
                    data=json.loads(data)
                    hasil = "Informasi \n" +str(data["Title"])+ " (" +str(data["Year"])+ ")"
                    hasil += "\n\n " +str(data["Plot"])
                    hasil += "\n\nDirector : " +str(data["Director"])
                    hasil += "\nActors   : " +str(data["Actors"])
                    hasil += "\nRelease : " +str(data["Released"])
                    hasil += "\nGenre    : " +str(data["Genre"])
                    hasil += "\nRuntime   : " +str(data["Runtime"])
                    path = data["Poster"]
                    cl.sendImageWithURL(msg.to, str(path))
                    cl.sendMessage(msg.to,hasil)
                    
                elif self.resp + 'get-ig ' in msg.text:
                    instagram = msg.text.replace(self.resp +'get-ig ','')
                    html = requests.get('https://www.instagram.com/' + instagram + '/')
                    soup = BeautifulSoup(html.text, 'html5lib')
                    data = soup.find_all('meta', attrs={'property':'og:description'})
                    text = data[0].get('content').split()
                    data1 = soup.find_all('meta', attrs={'property':'og:image'})
                    text1 = data1[0].get('content').split()
                    user = "Name: " + text[-2] + "\n"
                    user1 = "Username: " + text[-1] + "\n"
                    followers = "Followers: " + text[0] + "\n"
                    following = "Following: " + text[2] + "\n"
                    post = "Post: " + text[4] + "\n"
                    link = "Link: " + "https://instagram.com/" + instagram
                    cl.sendImageWithURL(msg.to, text1[0])
                    cl.sendMessage(msg.to, user + user1 + followers + following + post + link)
                    
                elif self.resp + 'igpost ' in msg.text:
                    instagram = msg.text.replace(self.resp +'igpost ','')
                    ig = instagram.split()
                    username = ig[0]
                    ke = ig[1]
                    r = requests.get('http://rahandiapi.herokuapp.com/instapost/'+username+'/'+ke+'?key=betakey', verify=True)
                    media = r.text
                    media = json.loads(media)
                    start = timeit.timeit()
                    hasil = "Informasi Post Instagram"
                    hasil += "\n\nLike       : " +str(media["media"]["like_count"])
                    hasil += "\nComment : " +str(media["media"]["comment_count"])
                    hasil += "\nCaption : \n\n" +str(media["media"]["caption"])
                    hasil += '\n\nTime taken : %s' % (start)
                    path = media["media"]["url"]
                    cl.sendImageWithURL(msg.to,path)
                    cl.sendMessage(msg.to,hasil)
                    
                #elif self.resp + 'igstory ' in msg.text:
                #    instagram = msg.text.replace(self.resp +'story ','')
                #    r = requests.get('http://rahandiapi.herokuapp.com/instastory/'+instagram'?key=betakey', verify=True)
                    
                    
                    
                elif self.resp + 'wsholat ' in msg.text:
                    location = msg.text.replace(self.resp +'wsholat ','')
                    with requests.session() as web:
                        web.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0"
                        r = web.get("http://api.corrykalam.net/apisholat.php?lokasi={}".format(urllib.parse.quote(location)))
                        data = r.text
                        data = json.loads(data)
                        if data[1] != "Subuh : " and data[2] != "Dzuhur : " and data[3] != "Ashr : " and data[4] != "Maghrib : " and data[5] != "Isha : ":
                            hasil = "Informasi Jadwal Sholat"
                            hasil += "\n\nâ  " + data[1]
                            hasil += "\nâ  " + data[2]
                            hasil += "\nâ  " + data[3]
                            hasil += "\nâ  " + data[4]
                            hasil += "\nâ  " + data[5]
                            hasil += "\nâ  Lokasi : " + data[0]
                            hasil += "\n "
                        else:
                            hasil = "Lokasi tidak ditemukan"
                        cl.sendMessage(msg.to, str(hasil))
                        
                elif self.resp + 'ccuaca ' in msg.text:
                    location = msg.text.replace(self.resp +'ccuaca ','')
                    with requests.session() as web:
                        web.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0"
                        r = web.get("http://api.corrykalam.net/apicuaca.php?kota={}".format(urllib.parse.quote(location)))
                        data = r.text
                        data = json.loads(data)
                        if "result" not in data:
                            hasil = "Informasi Cuaca"
                            hasil += "\n\nâ  Lokasi : " + data[0].replace("Temperatur di kota ","")
                            hasil += "\nâ  Suhu   : " + data[1].replace("Suhu : ","")
                            hasil += "\nâ  Kelembaban     : " + data[2].replace("Kelembaban : ","")
                            hasil += "\nâ  Tekanan Udara : " + data[3].replace("Tekanan udara : ","")
                            hasil += "\nâ  Kecepatan Angin : " + data[4].replace("Kecepatan angin : ","")
                            hasil += "\n "
                        else:
                            hasil = "Lokasi tidak ditemukan"
                        cl.sendMessage(msg.to, str(hasil))
                        
                elif self.resp +"inviteme" in msg.text:
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"]:
                        aku = msg._from
                        gid = cl.getGroupIdsJoined()
                        for i in gid:
                        	cl.inviteIntoGroup(i,[msg._from])

                elif self.resp + 'clokasi ' in msg.text:
                    location = msg.text.replace(self.resp +'clokasi ','')
                    with requests.session() as web:
                        web.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0"
                        r = web.get("http://api.corrykalam.net/apiloc.php?lokasi={}".format(urllib.parse.quote(location)))
                        data = r.text
                        data = json.loads(data)
                        if data[0] != "" and data[1] != "" and data[2] != "":
                            link = "https://www.google.co.id/maps/@{},{},15z".format(str(data[1]), str(data[2]))
                            hasil = "Informasi Lokasi"
                            hasil += "\n\nâ  Lokasi      : " + data[0]
                            hasil += "\nâ  Google Maps : " + link
                            hasil += "\n "
                        else:
                            hasil = "Lokasi tidak ditemukan"
                        cl.sendMessage(msg.to, str(hasil))
                    
                elif '/ti/g/' in msg.text.lower():
                    if msg._from in self.wait["Owner"] or msg._from in self.wait["RAAdmin"] or msg._from in self.wait["RAStaff"] or msg._from in self.wait["RABots"]:
                        link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                        links = link_re.findall(msg.text)
                        n_links=[]
                        for l in links:
                            if l not in n_links:
                                n_links.append(l)
                        for ticket_id in n_links:
                            if self.wait["RAautojoin"] == True:
                                group=cl.findGroupByTicket(ticket_id)
                                cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                

        except Exception as e:
            print(e)
                            
        