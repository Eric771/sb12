from client import LineBot
from XueAPI import *
from ninja import *
import json,threading,subprocess
crl ="DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0"
def login(resp, auth):
	bot = LineBot(resp, auth)

a1 = LINE("ewx7fum08s@mail.shenyin-linebot.com","nmsl0678",crl)
A1 = threading.Thread(target=login, args=('A1',str(a1.authToken))).start()

a2 = LINE("z3eanbbdoe@mail.shenyin-linebot.com","nmsl0678",crl)
A2 = threading.Thread(target=login, args=('A2',str(a1.authToken))).start()

a3 = LINE("xez68hbv0j@mail.shenyin-linebot.com","nmsl0678",crl)
A3 = threading.Thread(target=login, args=('A3',str(a1.authToken))).start()

a4 = LINE("soqku54vnk@mail.shenyin-linebot.com","nmsl0678",crl)
A4 = threading.Thread(target=login, args=('A4',str(a1.authToken))).start()

a5 = LINE("q37vffn7ay@mail.shenyin-linebot.com","nmsl0678",crl)
A5 = threading.Thread(target=login, args=('A5',str(a1.authToken))).start()

a6 = LINE("hxcsc298cd@mail.shenyin-linebot.com","nmsl0678",crl)
A6 = threading.Thread(target=login, args=('A6',str(a1.authToken))).start()

a7 = LINE("zwspvg8wft@mail.shenyin-linebot.com","nmsl0678",crl)
A7 = threading.Thread(target=login, args=('A7',str(a1.authToken))).start()

#a8 = LINE("EMAIL KAMU","PASSWRD KAMU",appname)
#A8 = threading.Thread(target=login, args=('A8',str(a1.authToken))).start()

#a9 = LINE("EMAIL KAMU","PASSWRD KAMU",appname)
#A9 = threading.Thread(target=login, args=('A9',str(a1.authToken))).start()

#a10 = LINE("EMAIL KAMU","PASSWRD KAMU",appname)
#A10 = threading.Thread(target=login, args=('A10',str(a1.authToken))).start()

#kalian bisa pagari jika kalian ingin mencoba login lebih sedikit
print('Login Berhasil!')
